from collections import defaultdict

import downloader_logic
import os, hashlib, re

# List of urls with filename that is missing md5
MISSING_MD5_PATH_LIST = set()

def check_each_combined_tld_part( tld_dir, interactive = True ):
    """
    For loop through all tld_combined parts. If checksums do not match redownload

    Parameters:
        tld_dir: String. Path to combined tld parts.
        interactive: Boolean. Determines if we want the users response before redownload

    Return:
        List. List is of bad filenames to redownload.
    """
    bad_files = list()
    tld_dir = os.path.expanduser(tld_dir)
    tld_dir = os.path.abspath(tld_dir)

    compiled_pattern = re.compile('.*\.[0-9]*$')
    for root, subdir, filelist in os.walk(tld_dir):
        for fn in filelist:
            if( compiled_pattern.match(fn) ):
                file_path = os.path.abspath(os.path.join(root,fn))

                if( not md5_check(file_path, file_path + ".md5") ):
                    bad_files.append(os.path.basename(file_path))

    if( len(bad_files) > 0 ):
        print bad_files
        if( interactive ):
            user_answer = raw_input("Would you like to redownload all these corrupt files [Y/N]: ")
            while( user_answer.upper() not in ["Y", "N", "YES", "NO"] ):
                print "Bad input '{0}'".format( user_answer )
                user_answer = raw_input("Would you like to redownload all these corrupt files [Y/N]: ")
                print

            if( user_answer.upper() in ["Y", "YES"] ):
                print "Redownloading Bad Files"
                print
                return bad_files
            else:
                print "Not redownloading"
                print
                return []
        else:
            print "Redownloading Bad Files"
            print
            return bad_files
        
    return []

def check_redownload_if_bad_checksums( dfeed, dir_files, base_file_url_dir, login, password,interactive = True, files_to_check = dict() ):
    """
    The method will constantly check and redownload bad files until they are 'good'
    
    Parameters
        dfeed: String. Data feed type. Each feeds seems to have own way of handling md5
        dir_files: String. Path to directory of files that we want to check md5 of.
        base_file_url_dir: String. Url to the base directory of files
        login: String. Username to redownload
        password: String. Password to redownload
        interactive: Boolean. Determines if we want to wait for user response for redownload
        files_to_check: Dictionary. If provided use to check those files specifically.
                        Contains file name as key and value of ChecksumURLs

    Return
        Nothing
    """

    # Check if there is a directory first. If not return
    if( not os.path.isdir(dir_files) ):
        return

    print "Checking downloaded files integrity..."

    #Check file integriy
    url_bad_files = check_directories_integrity( dfeed, dir_files, base_file_url_dir,  interactive, files_to_check )
    
    download_bad_files_max_3 = defaultdict(int)
    while( len(url_bad_files) > 0 ):
        for url in url_bad_files:
            download_bad_files_max_3[url] += 1
            print url
            downloader_logic.download_by_url(url, login, password, dir_files, False)

        url_bad_files = check_directories_integrity( dfeed, dir_files, base_file_url_dir, interactive, files_to_check )

        # If redownloaded 3 times and fails integrity checker, just stop and log
        for url in list(url_bad_files):
            if(download_bad_files_max_3[url] > 3):
                url_bad_files.remove(url)
                if("md5" not in url):
                    logging.error("{0} has failed md5 check 3 times.".format(url))

    print "File integrity checker complete."

    return

def check_directories_integrity( dfeed, dir_files, base_url_dir, interactive = True, files_to_check = dict() ):
    """
    Searches for all files in a folder 1 levelthat are .tar.gz and compares against the .md5 within that same folder.
    If md5 not found, print error message and store into 'URLS_MISSING_MD5_LIST' but do not redownload.

    Parameters
        dfeed: String. Data feed. Each data feed seems to do things their own ways. We want flexibility
        dir_files: String. Path to directory of files that we want to check md5 of.
        base_url_dir: String. Url to the base directory of files
        interactive: Boolean. Determines if we want to wait for user response for redownload
        files_to_check: Dictionary. Keys = Filename, Value = ChecksumURLs. Allows for easy list of redownload

    Return
        List. Bad file name urls.
    """
    global MISSING_MD5_PATH_LIST
    bad_files = list()
    checksum_urls = list()
    dir_files = os.path.expanduser(dir_files)
    dir_files = os.path.abspath(dir_files)

    # Daily data hash base url is ready when needed. Optimization technique
    if( "ngtld" not in dfeed ):
        hashes_daily_base_url = downloader_logic.getDailyGtldUrl(dfeed) + "/hashes"
    else:
        hashes_daily_base_url = downloader_logic.getDailyNGtldUrl(dfeed) + "/hashes"

    # Find either files ending in .csv or .gz to check integrity of
    compiled_pattern = re.compile('(.*\.gz$)|(.*\.csv$)')
    for fn in os.listdir(dir_files):
        if( compiled_pattern.match(fn) ):
            file_path = os.path.abspath(os.path.join(dir_files, fn))
            
            # Complex md5 paths
            if( dfeed in ['domain_names_new', 'domain_names_dropped', 'whois_record_delta_domain_names_change'] ):
                tmp, formatted_date = os.path.split(dir_files)
                daily_md5_name = formatted_date + "_" + fn + ".md5"
                md5_path = os.path.abspath(os.path.join(dir_files, daily_md5_name))
            
            # Default paths
            else:
                md5_path = file_path + ".md5"


            if( len(files_to_check) > 0 ): 
                if( fn in files_to_check and not os.path.isfile(md5_path) ):
                     MISSING_MD5_PATH_LIST.add(file_path)
                     continue

                if( fn in files_to_check and not md5_check(file_path, md5_path) ):
                    bad_files.append(files_to_check[fn].file_url)
                    checksum_urls.append(files_to_check[fn].md5_url)
            else:
                if( not os.path.isfile(md5_path) ):
                     MISSING_MD5_PATH_LIST.add(file_path)
                     continue

                # Attempt to redownload based on 'prior knowledge of location' and given base url
                if( not md5_check(file_path, md5_path) ):
                    url_file = base_url_dir + "/" + fn
                    bad_files.append(url_file)

                    if( dfeed in [ 'whois_database', 'domain_list_quarterly' ] ):
                        url_md5 = url_file + ".md5"

                    # YYYY_MM_DD_FILENAME
                    elif( dfeed in [ 'domain_names_new', 'domain_names_dropped', 'whois_record_delta_domain_names_change'] ):
                        formatted_date = base_url_dir.split("/")[-1]
                        url_md5 = hashes_daily_base_url + "/" + formatted_date + "_" + fn + ".md5"

                    else:
                        url_md5 = hashes_daily_base_url + "/" + fn + ".md5"
                        
                    checksum_urls.append(url_md5)


    if( len(bad_files) > 0 ):
        print bad_files
        if( interactive ):
            user_answer = raw_input("Would you like to redownload all these corrupt files [Y/N]: ")
            while( user_answer.upper() not in ["Y", "N", "YES", "NO"] ):
                print "Bad input '{0}'".format( user_answer )
                user_answer = raw_input("Would you like to redownload all these corrupt files [Y/N]: ")
                print

            if( user_answer.upper() in ["Y", "YES"] ):
                print "Redownloading Bad Files"
                print
                print checksum_urls
                bad_files.extend(checksum_urls)
                return bad_files
            else:
                print "Not redownloading"
                print
                return []
        else:
            print "Redownloading Bad Files"
            print
            bad_files.extend(checksum_urls)
            return bad_files
        
    return []

def md5_check( path_filename, md5_file_path ):
    """ Determines if the md5 checksum checks out

    Return:
        Returns a true if the checksum is correct.
    """
    calc_check_sum = calc_md5( path_filename )
    with open( md5_file_path ) as md5_file:
        correct_check_sum = md5_file.readline().split()[0].strip()
        if( calc_check_sum == correct_check_sum ):
            return True
    return False

def calc_md5( path_filename ):
    """ Calculates the md5 of a file
    
    Return:
        Returns the hex digits in string form representing md5 of file
    """
    hash_md5 = hashlib.md5()
    with open( path_filename , "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def printMissingMD5s():
    """
    Prints out the list of missing md5s if exists
    """
    global MISSING_MD5_PATH_LIST
    if( len(MISSING_MD5_PATH_LIST) > 0 ):
        print
        print "Cannot guarantee the correctness of these files due to missing their md5:"
        for f in sorted(MISSING_MD5_PATH_LIST):
            print f
        print
    
    return
