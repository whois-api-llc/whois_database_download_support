#!/usr/bin/env python
from whois_utils.downloader_logic import *
from whois_utils.download_checker import printMissingMD5s
from whois_utils.utils import mkdir_p
from whois_utils.utils import printIncorrectSpecifiedTlds
from whois_utils.utils import obtain_date_from_string

import argparse, ConfigParser
import logging, os, sys, errno
import datetime

"""
>>Future Suggestions
    - Most likely need to incoporate beautifulsoup to perform webscrape to 'download all' 
    instead of hardcoding download urls
        + Will definitely reduce the number liens of code and need for fixing in the future
"""

DEBUG = False

CURRENT_VERSION = "0.0.6"
workdir = os.path.dirname(os.path.realpath(__file__))
if( not os.path.isfile(os.path.abspath(os.path.join(workdir, 'config.ini'))) ):
    print "Missing config.ini.."
    print "Exiting."
    sys.exit(1)

setDownloadWorkingDirectory(workdir)

config_downloader = ConfigParser.ConfigParser()
config_downloader.read( os.path.abspath(os.path.join(workdir, 'config.ini')) )


# Setup logger
mkdir_p(os.path.join(workdir, "log"))
current_date = datetime.datetime.now()
logging.basicConfig(filename=os.path.join(workdir, "log", current_date.strftime("%Y_%m_%d_error") + ".log"), filemode='a', level=logging.INFO)
logging.info("========" + "Downloader started on " + current_date.strftime("%c") + "========")

# List of TLDs
# TLD_list = []
# NEWTLDS_url = config_downloader.get('gtld', 'NEWTLDS_url')

# List of data feed types
DFEED_types = ['domain_names_new',
               'domain_names_dropped',
               'domain_names_dropped_whois',
               'domain_names_whois',
               'domain_names_whois_filtered_reg_country',
               'domain_names_whois_filtered_reg_country_noproxy',
               'whois_record_delta_domain_names_change',
               'whois_record_delta_whois',
               'domain_names_whois_archive',
               'domain_names_whois_filtered_reg_country_archive',
               'domain_names_whois_filtered_reg_country_noproxy_archive',

               'ngtld_newly_registered_domains',
               'ngtld_recently_dropped_domains',
               'ngtld_recently_dropped_whois_domains',
               'ngtld_whois_data',
               'ngtld_whois_data_archive',
               'ngtld_domain_names_whois_filtered_reg_country',
               'ngtld_domain_names_whois_filtered_reg_country_noproxy',
               'ngtld_domain_names_whois_filtered_reg_country_archive',
               'ngtld_domain_names_whois_filtered_reg_country_noproxy_archive',

               'cctld_discovered_domain_names_new',
               'cctld_discovered_domain_names_whois',
               'cctld_registered_domain_names_new',
               'cctld_registered_domain_names_whois',
               'cctld_registered_domain_names_dropped',
               'cctld_registered_domain_names_dropped_whois',

               'whois_database',
               'domain_list_quarterly',
               'whois_database_combined'
]

# Available file formats
FORMATS_list = ['simple_csv', 'regular_csv', 'full_csv', 'mysqldump', 'docs', 'readme']

        

# Preparing arguments
argparser=argparse.ArgumentParser(description='Download whois data')
argparser.add_argument('-c', '--dfeed-type', type=str, required=True, choices = DFEED_types,
                        help='a type of data_feed (see the README)')
argparser.add_argument('-l', '--login', type=str, required=True, help='User login')
argparser.add_argument('-p', '--password', type=str, required=True, help='User password')

argparser.add_argument('-d', '--date', type=obtain_date_from_string, help='Date (format YYYY-MM-DD)')
argparser.add_argument('--end-date', type=obtain_date_from_string, help='End date of data (format YYYY-MM-DD)')
# argparser.add_argument('-n', '--num-days-ahead', type = int, default = 0,
                        # help = "If provided, creates a date range from --date to (--date + n) days." )
argparser.add_argument('-v', '--version', type=str, required=False, default='v0',
                        help='It is required for data feed type "whois_database" (DEFAULT: v0)')
argparser.add_argument('-t', '--tld', nargs = "*", type=str, required=False, default= ['all'],
                        help='TLDs for downloading (DEFAULT: all). Can have tlds space delimited "com aaa aarp" ')
argparser.add_argument('-f', '--file-format', nargs="*", type=str, choices=FORMATS_list + ['all'], required=False,
                        help='File formats you want. Space delimited'.format(FORMATS_list))
argparser.add_argument('-odir', '--output-dir', type=str, 
                        default= os.path.abspath( os.path.join(workdir, 'data') ),
                        help='Output directory for downloaded files, default=' + 
                        os.path.abspath( os.path.join(workdir, 'data') ) )
argparser.add_argument( '--interactive', action = 'store_true',
        help = "Asks the user if they would like to delete parts of whois_tld_combined if checksums do not match, and redownload. Default: Deletes and redownload parts that do not match." )
argparser.add_argument('--no-override', action = 'store_true',
        help = "If provided, do not download if file already exists")

args = argparser.parse_args()

# Set Global variable in download_logic
setDownloadOverrideGlobal(args.no_override)

# ============================
# Command line argument checks
# ============================
if(args.end_date is not None and args.end_date < args.date):
    print "End date cannot be a date before start date"
    sys.exit(1)

if( args.dfeed_type in ["whois_database", "domain_list_quarterly"] ):
    if( args.file_format is None):
        argparser.error("File format(--file-format) is required {0}".format(FORMATS_list))
    elif( args.version == "v0" ):
        argparser.error("Version (--version) is required")

tld = []
output_dir = args.output_dir

# ======================================
# Get supported tlds for daily data feed
# ======================================
dfeed_type = args.dfeed_type
dfeed_url = getDataFeedURL(dfeed_type)
TLD_list = get_tlds(dfeed_url, dfeed_type, args.date, args.login, args.password, args.version, args.output_dir)

if args.tld[0] == 'all' and dfeed_type != "whois_database_combined":
    tld = TLD_list
else:
    tld.extend(args.tld)

# Creating subdirectories recursively if they don't exist
mkdir_p(output_dir)


#========================================================
# Routes the wanted data feed to correct downloader logic
#========================================================

#===========================================
# Quarterly Data Feeds
#===========================================
if dfeed_type == "whois_database_combined":
    dfeed_url = getQuarterlyGtldUrl()

    #http://www.domainwhoisdatabase.com/whois_database/v17/csv/csv_tlds_combined/simple/simple-v15.tar.gz.0000
    if( args.file_format is None ):
        raise argparser.error("Missing file format")

    if( 'all' in args.file_format ):
        combined_format_list = FORMATS_list
    else:
        combined_format_list = args.file_format

    for f in combined_format_list:
        print "Output dir {0}".format( output_dir )
        print f
        if( f not in ['docs', 'readme'] ):
            download_whois_database_combined( dfeed_url, args.login, args.password, f,
                                    args.version, args.interactive, output_dir )
        else:
            download_whois_database(dfeed_url, args.login, args.password,
                                    f, args.version, tld, args.interactive, output_dir)
    printMissingMD5s()
    sys.exit()

# Here on out, we can specify TLDs
# Check if tld is correct
incorrect_tlds = []
if( 'all' not in args.tld ):
    for t in args.tld:
        if( t not in TLD_list ):
            incorrect_tlds.append(t)
            tld.remove(t)

if dfeed_type == "whois_database":
    dfeed_url = getQuarterlyGtldUrl( )

    if( args.file_format is None ):
        raise argparser.error("Missing file format")

    elif( args.version == "v1" ):
        if( 'all' in args.file_format ):
            print "Output dir {0}".format(output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'mysqldump', args.version, tld, args.interactive, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'docs', args.version, tld, args.interactive, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'readme', args.version, tld, args.interactive, output_dir)
        elif( 'full_csv' not in args.file_format and 'regular_csv' not in args.file_format \
                and 'simple_csv' not in args.file_format ):
            print "Output dir {0}".format(output_dir)
            for f in args.file_format:
                download_whois_database(dfeed_url, args.login, args.password,
                                    f, args.version, tld, args.interactive, output_dir)

        else:
            print "Database version 1 only contains mysqldump, docs, and readme"
            exit(1)

    elif( args.version == "v2"):
        if( 'all' in args.file_format ):
            print "Output dir {0}".format(output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'simple_csv', args.version, tld, args.interactive, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'mysqldump', args.version, tld, args.interactive, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'docs', args.version, tld, args.interactive, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'readme', args.version, tld, args.interactive, output_dir)
        elif( 'full_csv' not in args.file_format and 'regular_csv' not in args.file_format ):
            print "Output dir {0}".format(output_dir)
            for f in args.file_format:
                download_whois_database(dfeed_url, args.login, args.password,
                                    f, args.version, tld, args.interactive, output_dir)
        else:
            print "Database version 2 only contains mysqldump, simple_csv, docs, and readme"
            exit(1)
    else:
        print "Output dir {0}".format(output_dir)
        if( 'all' in args.file_format ):
            for f in FORMATS_list:
                download_whois_database(dfeed_url, args.login, args.password,
                                        f, args.version, tld, args.interactive, output_dir)
        else:
            for f in args.file_format:
                download_whois_database(dfeed_url, args.login, args.password,
                                        f, args.version, tld, args.interactive, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "domain_list_quarterly":
    dfeed_url = getQuarterlyCctldUrl( )


    #http://www.domainwhoisdatabase.com/domain_list_quarterly/v3/database_dump/mysqldump/info/domains_whoiscrawler_v3_info_mysql.sql.gz
    if( args.file_format is None ):
        raise argparser.error("Missing file format")
        sys.exit(1)

    if( 'all' in args.file_format ):
        domain_list_quarterly = FORMATS_list
    else:
        domain_list_quarterly = args.file_format

    for f in domain_list_quarterly:
        print "Output dir {0}".format( output_dir )
        download_domain_list_quarterly(dfeed_url, args.login, args.password,
                                f, args.version, args.interactive, tld, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


#===========================================
# Daily Data Feeds
#===========================================
# After quarterly release, check if date is present.
# Date is needed for daily data
if( args.date is None ):
    print "Date required: Date (format YYYY-MM-DD)"
    sys.exit(1)

if dfeed_type == "domain_names_new":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_new(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_dropped":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_dropped(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_filtered_reg_country":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_filtered_reg_country(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_filtered_reg_country_noproxy":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_filtered_reg_country_noproxy(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "whois_record_delta_domain_names_change":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_whois_record_delta_domain_names_change(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "whois_record_delta_whois":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_whois_record_delta_whois(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_filtered_reg_country_archive":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_filtered_reg_country_archive(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_filtered_reg_country_noproxy_archive":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_filtered_reg_country_noproxy_archive(dfeed_url, args.date, args.login, 
                                                        args.password, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "ngtld_newly_registered_domains":
    dfeed_url = getDailyNGtldUrl( "domain_names_new" )
    download_domain_names_new(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_recently_dropped_domains":
    dfeed_url = getDailyNGtldUrl( "domain_names_dropped" )
    download_domain_names_dropped(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_domain_names_whois_filtered_reg_country":
    dfeed_url = getDailyNGtldUrl("domain_names_whois_filtered_reg_country")
    download_domain_names_whois_filtered_reg_country(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_domain_names_whois_filtered_reg_country_noproxy":
    dfeed_url = getDailyNGtldUrl("domain_names_whois_filtered_reg_country_noproxy")
    download_domain_names_whois_filtered_reg_country_noproxy(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_domain_names_whois_filtered_reg_country_archive":
    dfeed_url = getDailyNGtldUrl("domain_names_whois_filtered_reg_country_archive")
    download_domain_names_whois_filtered_reg_country_archive(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_domain_names_whois_filtered_reg_country_noproxy_archive":
    dfeed_url = getDailyNGtldUrl("domain_names_whois_filtered_reg_country_noproxy_archive")
    download_domain_names_whois_filtered_reg_country_noproxy_archive(dfeed_url, args.date, args.login, 
                                                        args.password, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "cctld_discovered_domain_names_new":
    dfeed_url = getDailyCctldDiscoveredUrl("domain_names_new")
    download_domain_names_new(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "cctld_registered_domain_names_new":
    dfeed_url = getDailyCctldRegisteredUrl("domain_names_new")
    download_domain_names_new(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "cctld_registered_domain_names_dropped":
    dfeed_url = getDailyCctldRegisteredUrl("domain_names_dropped")
    download_domain_names_dropped(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

# Check file format
file_format = args.file_format
domain_names_file_format = ["regular_csv", "full_csv", "mysqldump"]
valid_user_file_formats = domain_names_file_format + ["all"]
if( args.file_format is None ):
    raise argparser.error("Missing file format\n{0}".format(domain_names_file_format))
    sys.exit(1)

for ff in file_format:
    if ff not in valid_user_file_formats:
        print "You have to specify --file-format properly (%s) for this type of data_feed (%s)" % (
            valid_user_file_formats, dfeed_type)
        printMissingMD5s()
        printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
        sys.exit()

# DAILY GTLD
if dfeed_type == "domain_names_whois":
    dfeed_url = getDailyGtldUrl( dfeed_type )

    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, 
                    ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, 
                    ff, tld, args.end_date, args.interactive, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_dropped_whois":
    dfeed_url = getDailyGtldUrl( "domain_names_dropped_whois" )
    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_archive":
    dfeed_url = getDailyGtldUrl( dfeed_type )

    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois_archive(dfeed_url, args.date, args.login, args.password, 
                    ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois_archive(dfeed_url, args.date, args.login, args.password, 
                    ff, tld, args.end_date, args.interactive, output_dir)

    # download_domain_names_whois_archive(dfeed_url, args.date, args.login, args.password,
                              # tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

# DAILY NGTLD
if dfeed_type == "ngtld_whois_data":
    dfeed_url = getDailyNGtldUrl( "domain_names_whois" )
    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_recently_dropped_whois_domains":
    dfeed_url = getDailyNGtldUrl( "domain_names_dropped_whois" )
    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_whois_data_archive":
    dfeed_url = getDailyNGtldUrl("domain_names_whois_archive")

    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois_archive(dfeed_url, args.date, args.login, args.password, 
                    ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois_archive(dfeed_url, args.date, args.login, args.password, 
                    ff, tld, args.end_date, args.interactive, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()
# DAILY CCTLD DISCOVERED
if dfeed_type == "cctld_discovered_domain_names_whois":
    dfeed_url = getDailyCctldDiscoveredUrl("domain_names_whois")

    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, ff, tld, args.end_date, args.interactive, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


# DAILY CCTLD NEWLY REGISTERED
if dfeed_type == "cctld_registered_domain_names_whois":
    dfeed_url = getDailyCctldRegisteredUrl("domain_names_whois")

    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, ff, tld, args.end_date, args.interactive, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "cctld_registered_domain_names_dropped_whois":
    dfeed_url = getDailyCctldRegisteredUrl("domain_names_dropped_whois")
    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

