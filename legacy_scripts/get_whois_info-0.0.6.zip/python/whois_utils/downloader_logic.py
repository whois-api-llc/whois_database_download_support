import ConfigParser, datetime, requests, os, sys, time

from collections import defaultdict
from collections import namedtuple

from download_checker import check_each_combined_tld_part
from download_checker import check_redownload_if_bad_checksums
from download_checker import check_directories_integrity
from download_checker import md5_check
from download_checker import calc_md5

from urlparse import urlparse

from utils import mkdir_p
from utils import date_to_string

# Global
_OVERRIDE_DOWNLOADS = False
WORKDIR = ""

CONFIG_DOWNLOADER = ConfigParser.ConfigParser()


ChecksumURLs = namedtuple('ChecksumURLs', ['file_url', 'md5_url'])

def setDownloadOverrideGlobal(answer):
    global _OVERRIDE_DOWNLOADS
    _OVERRIDE_DOWNLOADS = answer

def setDownloadWorkingDirectory(path):
    global WORKDIR
    WORKDIR = path
    CONFIG_DOWNLOADER.read( os.path.abspath(os.path.join(WORKDIR, 'config.ini')) )

def getDailyCctldDiscoveredUrl(dfeed_str):
    """
    Constructs base url for daily cctld feed
    """
    return CONFIG_DOWNLOADER.get('cctld', 'daily_discovered_cctld_url') + "/" + dfeed_str

def getDailyCctldRegisteredUrl(dfeed_str):
    """
    Constructs base url for daily cctld feed
    """
    return CONFIG_DOWNLOADER.get('cctld', 'daily_registered_cctld_url') + "/" + dfeed_str

def getDailyGtldUrl( dfeed_str ):
    """Constructs url for daily gtld feed
    
    Parameters:
       dfeed_str: A string representing the feed type

    Return:
        URL representing where a data feed is located
    """
    return CONFIG_DOWNLOADER.get('gtld', 'daily_gtld_url') + "/" + dfeed_str

def getDailyNGtldUrl( dfeed_str ):
    """Constructs url for daily ngtld feed
    
    Parameters:
       dfeed_str: A string representing the feed type

    Return:
        URL representing where a data feed is located
    """
    return CONFIG_DOWNLOADER.get("gtld", "daily_ngtld_url") + "/" + dfeed_str

def getQuarterlyGtldUrl( ):
    """Constructs url for quarterly ngtld feed
    
    Parameters:
       dfeed_str: A string representing the feed type

    Return:
        URL representing where a data feed is located
    """
    return CONFIG_DOWNLOADER.get("gtld", "quarterly_gtld_url")

def getQuarterlyCctldUrl( ):
    """Constructs url for quarterly cctld feed

    Parameters:
        dfeed_str: String representing the data feed type

    Return:
        URL representing where data feed location
    """
    return CONFIG_DOWNLOADER.get("cctld", "quarterly_cctld_url")



def download_by_url(url, login, password, output_dir, file_exist_check = _OVERRIDE_DOWNLOADS):
    filename = os.path.basename(urlparse(url).path)
    filename = os.path.abspath(os.path.join(output_dir, filename))

    # Make dir to output files to
    mkdir_p(output_dir)

    if( file_exist_check and os.path.isfile(filename) ):
        print "{0} already exists".format( filename )
        return True
        
    s = requests.Session()
    s.auth = (login, password)


    url_print = os.path.basename(url)
    # Redownload file, if problem occurs with network
    while True:
        try:
            r = s.get(url, stream=True, timeout=30)

            if r.status_code == 200:
                with open(filename, 'wb') as out:
                    if( 'content-length' in (r.headers) ):
                        dl_total_length = int(r.headers.get('content-length'))
                    dl_size=0
                    dl_start_chunk = datetime.datetime.now()

                    sys.stdout.write("\r                                                    ")
                    sys.stdout.flush()
                    for chunk in r.iter_content(chunk_size=(1024*1024)):
                        out.write(chunk)
                        dl_end_chunk = datetime.datetime.now()
                        dl_size += len(chunk)
                        #if dl_start_chunk != 0 and 'content-length' in (r.headers):
                        if 'content-length' in (r.headers):
                            # dl_done = int(100 * dl_size / dl_total_length)
                            dl_done = float(dl_size) / dl_total_length
                            dl_dtdelta = ( dl_end_chunk - dl_start_chunk ).microseconds
                            # sys.stdout.write("\r%s %s" % (dl_done, str( 1024 * 60 / dl_dtdelta) ))
                            # sys.stdout.write("\r{0:.2%} {1}".format(dl_done, str( 1024 * 60 / dl_dtdelta) ))
                            sys.stdout.write("\r{0} Progress: {1:.2%}".format(url_print, dl_done))
                            sys.stdout.flush()
                        dl_start_chunk = datetime.datetime.now()
                # sys.stdout.write("\rFile has been downloaded successfully".format(1))

                # Clears line
                sys.stdout.write("\r{0} [OK]                          ".format(url_print))
                sys.stdout.flush()
                # print "File has been downloaded successfully."
            elif r.status_code == 401:
                print "HTTP %s Unauthorized. Login credentials are wrong." % r.status_code
                try:
                    os.rmdir(output_dir);
                except OSError:
                    pass

                sys.exit(1)
                return False
            else:
                sys.stdout.write("\r{0} [Failed]\n".format(url_print))
                sys.stdout.flush()
                # print "Error HTTP %s File Not Found" % r.status_code
                # print
                try:
                    os.rmdir(output_dir);
                except OSError:
                    pass
                return False
            print ""

            return True
        except requests.exceptions.Timeout or requests.exceptions.ConnectionError:
            sys.stdout.write("\rNetwork timed out. Attempting redownload..")
            sys.stdout.flush()
            time.sleep(4)
            continue
        except requests.exceptions.ConnectionError or requests.exceptions.ChunkedEncodingError:
            sys.stdout.write("\rNetwork timed out. Attempting redownload..")
            sys.stdout.flush()
            time.sleep(4)
            continue
        except requests.exceptions.ChunkedEncodingError:
            sys.stdout.write("\rChunked Encoding Error. Redownloading")
            sys.stdout.flush()
            time.sleep(4)
            continue


def daily_download_readme( url, login, password, output_dir = os.path.abspath(os.path.join(".", "data"))):
    """
    Downloads the README for each daily data
    """
    if( not os.path.isfile(os.path.abspath(os.path.join(output_dir, "README"))) ):
        url_readme = url + "/" + "README"
        download_by_url(url_readme, login, password, output_dir)


#$tld/yyyy-MM-dd/add.$tld.csv
#for example, if you want to get newly registered .com domain names on November 25th, 2013, the corresponding file is
#com/2013-11-25/add.com.csv
def download_domain_names_new(url, date, login, password, tld_list, end_date = None, interactive = False, output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_new'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download Readme if it does not exist already
    if("ngtld" in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "ngtlds_domain_name_data" , "domain_names_new"))
    elif('cctld_domain_name_data' in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "cctld_domain_name_data", "domain_names_new"))
    elif('domain_name_data' in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_name_data", "domain_names_new"))
    else:
        final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_list", "domain_names_new") )

    daily_download_readme( url, login, password, final_output_dir )
    # Hashes base url
    url_hash_base = url + "/hashes"

    while( cur_date <= end_date ):
        check_sum_dict = dict()
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)

            # Daily cctld has a different format
            if('domain_list' in url):
                url_base_dir = url + "/" + formatted_date
            elif('cctld_domain_name_data' in url):
                url_base_dir = url + "/" + formatted_date
            else:
                url_base_dir = url + "/" + tld + "/" + formatted_date

            if("ngtld" in url):
                final_output_dir = os.path.abspath(os.path.join(output_dir, "ngtlds_domain_name_data" , "domain_names_new", tld, formatted_date))
            elif('cctld_domain_name_data' in url):
                final_output_dir = os.path.abspath(os.path.join(output_dir, "cctld_domain_name_data", "domain_names_new", formatted_date))
            elif('domain_name_data' in url):
                final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_name_data", "domain_names_new", tld, formatted_date))
            else:
                final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_list", "domain_names_new",formatted_date) )

            # If daily cctld, file format is different
            if('domain_list' in url):
                csv_name = tld
            else:
                csv_name = "add.%s.csv" % tld

            print final_output_dir 
            url_tld = url_base_dir + "/" + csv_name 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + formatted_date + "_" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            download_by_url(url_sha256, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base_dir, login, password, interactive, check_sum_dict )
        cur_date = cur_date + datetime.timedelta( days = 1 )

    return 1


#$tld/yyyy-MM-dd/dropped.$tld.csv
#for example, if	you want to get	newly dropped .com domain names on November 25th, 2013, the corresponding file is
#com/2013-11-25/dropped.com.csv
def download_domain_names_dropped(url, date, login, password, tld_list, end_date = None, interactive = False, 
        output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_dropped'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download README
    if("ngtld" in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir,  
                "ngtlds_domain_name_data", "domain_names_dropped"))
    elif("cctld_domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "cctld_domain_name_data", "domain_names_dropped") )
    elif("domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", "domain_names_dropped") )

    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"

    while( cur_date <= end_date ):
        check_sum_dict = dict()
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            if("ngtld" in url):
                final_output_dir = os.path.abspath(os.path.join(output_dir,  
                        "ngtlds_domain_name_data", "domain_names_dropped", tld, formatted_date))
            elif("cctld_domain_name_data" in url):
                final_output_dir = os.path.abspath( os.path.join(output_dir, "cctld_domain_name_data", "domain_names_dropped", formatted_date) )
            elif("domain_name_data" in url):
                final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", "domain_names_dropped", tld, formatted_date) )


            # cctld_domain_name_data formats differently
            if("cctld_domain_name_data" in url):
                url_base_dir = url + "/" + formatted_date
            else:
                url_base_dir = url + "/" + tld + "/" + formatted_date

            csv_name = "dropped.%s.csv" % tld
            url_tld = url_base_dir + "/" + csv_name 
            print final_output_dir 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + formatted_date + "_" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            download_by_url(url_sha256, login, password, final_output_dir)

            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base_dir, login, password, interactive, check_sum_dict )
        cur_date = cur_date + datetime.timedelta( days = 1 )

    return 1


def download_domain_names_dropped_whois(url, date, login, password, file_format, tld_list, 
                                end_date = None,
                                interactive = False,
                                output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_dropped_whois'
    #['regular_csv', 'full_csv', 'mysqldump']

    cur_date = date

    if(end_date is None):
        end_date = cur_date
    
    print
    #yyyy_MM_dd_$tld.csv.gz
    if("ngtld" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "ngtlds_domain_name_data", dfeed) )
    elif("cctld_domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "cctld_domain_name_data", dfeed) )
    elif("domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )


    # Hashes base url
    url_hash_base = url + "/hashes"

    if(file_format in ['regular_csv', 'full_csv']):
        csv_check_dict = dict()
        while( cur_date <= end_date ):
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')

                if(file_format == 'regular_csv'):
                    csv_name = "%s_%s.csv.gz" % (formatted_date, tld)
                elif(file_format == 'full_csv'):
                    csv_name = "full_%s_%s.csv.gz" % (formatted_date, tld)

                url_tld = url + "/" + csv_name 
                print final_output_dir 
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1


    #add_mysqldump_yyyy_MM_dd/$tld/add_mysqldump_yyyy_MM_dd_$tld.sql.gz
    if file_format == 'mysqldump':
        while( cur_date <= end_date ):
            csv_check_dict = dict()
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')
                csv_name = 'dropped_mysqldump_%s_%s.sql.gz' % (formatted_date, tld)

                url_tld = url + '/dropped_mysqldump_%s/%s/' % (formatted_date, tld) + csv_name
                print final_output_dir 
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)
            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1

    return 0

def download_domain_names_whois_filtered_reg_country( url, date, login, password, tld_list,
                                                     end_date = None, interactive = False, output_dir= os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_whois_filtered_reg_country'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print
    #yyyy_MM_dd_$tld.csv.gz
    if("ngtld" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "ngtlds_domain_name_data", dfeed))
    elif( "domain_name_data" in url ):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed))

    #filtered_reg_country_2015_09_10_aero.tar.gz

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"

    csv_check_dict = dict()
    while( cur_date <= end_date ):
        formatted_date = date_to_string(cur_date)
        formatted_date = formatted_date.replace('-', '_')
        for tld in tld_list:
            csv_name = "filtered_reg_country_%s_%s.tar.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name 

            print final_output_dir 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            download_by_url(url_sha256, login, password, final_output_dir)

            # Generate file checksum data for integrity checker
            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_domain_names_whois_filtered_reg_country_noproxy(url, date, login, password, tld_list,
                                                             end_date = None, 
                                                             interactive = False,
                                                             output_dir = os.path.abspath(os.path.join( ".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_whois_filtered_reg_country_noproxy'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print
    #yyyy_MM_dd_$tld.csv.gz
    if("ngtld" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "ngtlds_domain_name_data", dfeed))
    elif( "domain_name_data" in url ):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed))

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"

    #filtered_reg_country_noproxy_2015_11_18_org.tar.gz

    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            csv_name = "filtered_reg_country_noproxy_%s_%s.tar.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            download_by_url(url_sha256, login, password, final_output_dir)

            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_whois_record_delta_domain_names_change(url, date, login, password, tld_list,
                                                    end_date = None, interactive = False,
                                                    output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'whois_record_delta_domain_names_change'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"
    #auto/2015_11_11/auto.csv
    while( cur_date <= end_date ):
        check_sum_dict = dict()
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed, tld, formatted_date) )

            url_base = url + "/%s/%s" % (tld, formatted_date)
            csv_name = "%s.csv" % (tld)
            url_tld = url_base + "/" + csv_name 
            print final_output_dir 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + formatted_date + "_" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            download_by_url(url_sha256, login, password, final_output_dir)

            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, check_sum_dict )
        cur_date = cur_date + datetime.timedelta( days = 1 )

    return 1

def download_whois_record_delta_whois(url, date, login, password, tld_list,
                                    end_date = None, interactive = False,
                                    output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'whois_record_delta_whois'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"
    #2015_11_15_gmo.csv.gz
    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            csv_name = "%s_%s.csv.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            download_by_url(url_sha256, login, password, final_output_dir)

            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_domain_names_whois_archive(url, date, login, password, file_format, tld_list, 
                                end_date = None,
                                interactive = False,
                                output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_whois_archive'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    if("ngtld" in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "ngtlds_domain_name_data", dfeed))
    elif("domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )

    # Download README if not present
    daily_download_readme( url, login, password, final_output_dir )
    print

    # Hashes base url
    url_hash_base = url + "/hashes"

    if(file_format in ['regular_csv', 'full_csv']):
        #2013_05_09_net.csv.gz
        csv_check_dict = dict()
        while( cur_date <= end_date ):
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')
                
                if(file_format == 'regular_csv'):
                    csv_name = "%s_%s.csv.gz" % (formatted_date, tld)
                elif(file_format == 'full_csv'):
                    csv_name = "full_%s_%s.csv.gz" % (formatted_date, tld)

                url_tld = url + "/" + csv_name
                print final_output_dir 
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                download_by_url(url_sha256, login, password, final_output_dir)
                
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            cur_date = cur_date + datetime.timedelta( days = 1 )

        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1

    #add_mysqldump_yyyy_MM_dd/$tld/add_mysqldump_yyyy_MM_dd_$tld.sql.gz
    if(file_format == 'mysqldump'):
        while( cur_date <= end_date ):
            csv_check_dict = dict()
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')
                csv_name = 'add_mysqldump_%s_%s.sql.gz' % (formatted_date, tld)

                url_tld = url + '/add_mysqldump_%s/%s/' % (formatted_date, tld) + csv_name
                print final_output_dir 
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)
            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1

    return 0

def download_domain_names_whois_filtered_reg_country_archive(url, date, login, password, tld_list,
                                                             end_date = None, 
                                                             interactive = False,
                                                             output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_whois_filtered_reg_country_archive'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print
    if("ngtld" in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "ngtlds_domain_name_data", dfeed))
    elif("domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )

    # Hashes base url
    url_hash_base = url + "/hashes"

    #filtered_reg_country_2015_07_28_us.tar.gz
    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            
            csv_name = "filtered_reg_country_%s_%s.tar.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            download_by_url(url_sha256, login, password, final_output_dir)

            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_domain_names_whois_filtered_reg_country_noproxy_archive(url, date, login, password, tld_list,
                                                                     end_date = None, 
                                                                     interactive = False,
                                                                     output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_whois_filtered_reg_country_noproxy_archive'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print
    if("ngtld" in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "ngtlds_domain_name_data", dfeed))
    elif("domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )

    # Hashes base url
    url_hash_base = url + "/hashes"

    #filtered_reg_country_noproxy_2013_01_01_coop.tar.gz
    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            
            csv_name = "filtered_reg_country_noproxy_%s_%s.tar.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            download_by_url(url_sha256, login, password, final_output_dir)

            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_domain_names_whois(url, date, login, password, file_format, tld_list, 
                                end_date = None,
                                interactive = False,
                                output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_whois'
    #['regular_csv', 'full_csv', 'mysqldump']

    cur_date = date

    if(end_date is None):
        end_date = cur_date
    
    print
    #yyyy_MM_dd_$tld.csv.gz
    if("ngtld" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "ngtlds_domain_name_data", dfeed))
    elif( "cctld_domain_name_data" in url ):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "cctld_domain_name_data", dfeed))
    elif( "domain_name_data" in url ):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed))
    else:
        final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_list", dfeed))

    # Hashes base url
    url_hash_base = url + "/hashes"

    if(file_format in ['regular_csv', 'full_csv']):
        csv_check_dict = dict()
        while( cur_date <= end_date ):
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')

                if(file_format == 'regular_csv'):
                    csv_name = "%s_%s.csv.gz" % (formatted_date, tld)
                elif(file_format == 'full_csv'):
                    csv_name = "full_%s_%s.csv.gz" % (formatted_date, tld)

                url_tld = url + "/" + csv_name 
                print final_output_dir 
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1

    #add_mysqldump_yyyy_MM_dd/$tld/add_mysqldump_yyyy_MM_dd_$tld.sql.gz
    if file_format == 'mysqldump':
        while( cur_date <= end_date ):
            csv_check_dict = dict()
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')
                csv_name = 'add_mysqldump_%s_%s.sql.gz' % (formatted_date, tld)

                url_tld = url + '/add_mysqldump_%s/%s/' % (formatted_date, tld) + csv_name
                print final_output_dir 
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)
            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1

    return 0


def download_whois_database_combined(url, login, password, file_format, version, interactive,
                            output_dir= os.path.join( WORKDIR, "data" )):
    url_tld = ''
    end_range = 10000
    #['simple_csv', 'regular_csv', 'full_csv', 'mysqldump']
    print
    #whois_database/v13/csv/tlds/regular/csvs.abb.regular.tar.gz
    if( file_format in ['simple_csv', 'regular_csv', 'full_csv', 'mysqldump'] ):
        file_format_correct = file_format.split("_")[0]
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, 'whois_database_combined', file_format_correct) )

        # Check file existence before redownloading.
        # Starts on the last downloaded
        last_downloaded = 0
        if( os.path.isdir(final_output_dir) ):
            for i in range( 0, end_range):
                if( os.path.isfile(os.path.join(final_output_dir, "{0}-{1}.tar.gz.{2:04d}".format(file_format_correct, version, i))) ):
                    last_downloaded = i
                else:
                    break

        # Debug for loop
        # for i in range(0, 1):
        print "Starting download on part {0:04d}".format( last_downloaded )
        print final_output_dir 
        print

        for i in range(last_downloaded, end_range):
            if( file_format == "mysqldump" ):
                url_part = url + "/{0}/database_dump/mysqldump_combined/{1}-{0}.tar.gz.{2:04d}".format(version, file_format_correct, i)
            else:
                url_part = url + "/{0}/csv/tlds_combined/{1}-{0}.tar.gz.{2:04d}".format(version, file_format_correct, i)
            url_md5 = url_part + ".md5"
            url_sha = url_part + ".sha256" 

            if( not download_by_url(url_md5, login, password, final_output_dir) ):
                break

            if( not download_by_url(url_sha, login, password, final_output_dir) ):
                break
            
            if( not download_by_url(url_part, login, password, final_output_dir) ):
                break

        print "Checking file integrity.."
        bad_files = check_each_combined_tld_part(final_output_dir, interactive)
        bad_file_max_check_3 = defaultdict(int)
        while( len(bad_files) > 0 ):
            file_format_correct = file_format.split("_")[0]
            final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, 'whois_database_combined', file_format_correct) )
            print final_output_dir 
            for filename in bad_files:
                bad_file_max_check_3[filename] += 1
                if( file_format == "mysqldump" ):
                    url_part = url + "/{0}/database_dump/mysqldump_combined/{1}".format(version, filename)
                else:
                    url_part = url + "/{0}/csv/tlds_combined/{1}".format(version, filename)
                url_md5 = url_part + ".md5"
                url_sha = url_part + ".sha256" 

                if( not download_by_url(url_md5, login, password, final_output_dir) ):
                    break

                if( not download_by_url(url_sha, login, password, final_output_dir) ):
                    break
                
                if( not download_by_url(url_part, login, password, final_output_dir) ):
                    break

            print "Checking file integrity.."
            bad_files = check_each_combined_tld_part(final_output_dir, interactive)

            for fn in list(bad_files):
                if(bad_file_max_check_3[fn] > 3):
                    bad_files.remove(fn)
                    logging.error("Whois database aggregate file {0} has failed md5 check 3 times.".format(fn))


        print "File integrity checker complete."

        return True

    return False


def download_whois_database(url, login, password, file_format, version, tld_list, interactive = False,
        output_dir= os.path.join( WORKDIR, "data" ) ):
    """
    Possible enhancements:
        Somehow generate one loop to handle downloading of all data instead of it being so hardcoded.
    """
    dfeed = 'whois_database'
    url_tld = ''
    #['simple_csv', 'regular_csv', 'full_csv', 'mysqldump']

    print
    #whois_database/v17/docs/
    if file_format == 'docs':
	# Download countries file
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "docs") )
	url_base = url + "/%s/docs" % (version)
	url_countries = url_base + "/countries"
	download_by_url(url_countries, login, password, final_output_dir)

	# Download .tlds
	url_tlds = url_base + "/%s.tlds" % (version)
	download_by_url(url_tlds, login, password, final_output_dir)

	# Download csv scehma
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "docs", "csv", "schema") )
	url_schema_base = url_base + "/csv/schema"
	url_load_into_db = url_schema_base + "/load_csv_file_into_db.sh"
	download_by_url(url_load_into_db, login, password, final_output_dir)

	url_loader_full = url_schema_base + "/loader_schema_full.sql"
	download_by_url(url_loader_full, login, password, final_output_dir)

	url_loader_reg_daily = url_schema_base + "/loader_schema_regular_daily.sql"
	download_by_url(url_loader_reg_daily, login, password, final_output_dir)

	url_loader_reg_quarterly = url_schema_base + "/loader_schema_regular_quarterly.sql"
	download_by_url(url_loader_reg_quarterly, login, password, final_output_dir)

	url_loader_simple = url_schema_base + "/loader_schema_simple.sql"
	download_by_url(url_loader_simple, login, password, final_output_dir)

	# Download Scripts	
        download_script_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "docs", "download_scripts") )
        url_download_scripts_base = url_base + "/download_scripts"

        url_bash_base = url_download_scripts_base + "/bash"
        final_output_dir = os.path.abspath( os.path.join(download_script_dir, "bash") )
        url_bash_make = url_bash_base + "/Makefile"
	download_by_url(url_bash_make, login, password, final_output_dir)

        url_bash_readme = url_bash_base + "/README"
	download_by_url(url_bash_readme, login, password, final_output_dir)

        url_bash_ft = url_bash_base + "/ft_whoisdownload"
	download_by_url(url_bash_ft, login, password, final_output_dir)

        url_bash_sup_gtlds = url_bash_base + "/supported_gtlds"
	download_by_url(url_bash_sup_gtlds, login, password, final_output_dir)

        url_bash_sup_ngtlds = url_bash_base + "/supported_ngtlds"
	download_by_url(url_bash_sup_ngtlds, login, password, final_output_dir)

        url_bash_tlds = url_bash_base + "/tlds-01.text"
	download_by_url(url_bash_tlds, login, password, final_output_dir)

        url_bash_ut_whois_download = url_bash_base + "/ut_whoisdownload"
	download_by_url(url_bash_ut_whois_download, login, password, final_output_dir)

        url_bash_whois_download = url_bash_base + "/whoisdownload.sh"
	download_by_url(url_bash_whois_download, login, password, final_output_dir)

        url_python_base = url_download_scripts_base + "/python"
        final_output_dir = os.path.abspath( os.path.join(download_script_dir, "python") )
        url_python_readme = url_python_base + "/README"
	download_by_url(url_python_readme, login, password, final_output_dir)

        url_python_config = url_python_base + "/config.ini"
	download_by_url(url_python_config, login, password, final_output_dir)

        url_python_downloader = url_python_base + "/get_whois_info.py"
	download_by_url(url_python_downloader, login, password, final_output_dir)

        url_python_sup_gtlds = url_python_base + "/supported_gtlds"
	download_by_url(url_python_sup_gtlds, login, password, final_output_dir)

        url_python_sup_ngtlds = url_python_base + "/supported_ngtlds"
	download_by_url(url_python_sup_ngtlds, login, password, final_output_dir)

        # Download mysql scripts
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "docs", "mysql") )
        mysql_base_url = url_base + "/mysql"

        url_file = mysql_base_url + "/load_mysql_data_all.sh"
        download_by_url(url_file, login, password, final_output_dir)

        url_file = mysql_base_url + "/load_mysql_data_all_for_all_tlds.sh"
        download_by_url(url_file, login, password, final_output_dir)

        url_file = mysql_base_url + "/load_mysql_data_all_for_tld.sh"
        download_by_url(url_file, login, password, final_output_dir)

        url_file = mysql_base_url + "/load_mysql_data_per_tables.sh"
        download_by_url(url_file, login, password, final_output_dir)
         

        url_file = mysql_base_url + "/load_mysql_data_per_tables_for_all_tlds.sh"
        download_by_url(url_file, login, password, final_output_dir)

        url_file = mysql_base_url + "/load_mysql_data_per_tables_for_tld.sh"
        download_by_url(url_file, login, password, final_output_dir)


        url_file = mysql_base_url + "/load_mysql_schema.sh"
        download_by_url(url_file, login, password, final_output_dir)

        return 1

    #whois_database/v17/README.txt
    if file_format == 'readme':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version) )
	url_readme = url + "/%s/README.txt" % (version)
	download_by_url(url_readme, login, password, final_output_dir)
        return 1

    #whois_database/v13/csv/tlds/simple/csvs.abb.simple.tar.gz

    if file_format == 'simple_csv':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "simple") )
        downloaded_file_names = dict()
        if( version == "v2" ):
            url_base = url + "/{0}/csv".format(version)

            csv_name = "whois_v2_db_export_data_csv_simple.tar.gz"
            url_tld = url_base + "/" + csv_name
            print final_output_dir 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_md5 = url_tld + ".md5"
            download_by_url(url_tld_md5, login, password, final_output_dir)

            url_tld_sha256 = url_tld + ".sha256"
            download_by_url(url_tld_sha256, login, password, final_output_dir)

            downloaded_file_names[csv_name] = ChecksumURLs(url_tld, url_tld_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        else:
            print final_output_dir 
            url_base = url + "/{0}/csv/tlds/simple".format(version)
            for tld in tld_list:
                filename = "csvs.%s.simple.tar.gz" % (tld)
                url_tld = url_base + "/" + filename
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_md5 = url_tld + ".md5"
                download_by_url(url_tld_md5, login, password, final_output_dir)

                url_tld_sha256 = url_tld + ".sha256"
                download_by_url(url_tld_sha256, login, password, final_output_dir)

                downloaded_file_names[filename] = ChecksumURLs(url_tld, url_tld_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        return 1

    #whois_database/v13/csv/tlds/regular/csvs.abb.regular.tar.gz
    if file_format == 'regular_csv':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "regular") )
        url_base = url + "/{0}/csv/tlds/regular".format(version)
        downloaded_file_names = dict()

        print final_output_dir 
        for tld in tld_list:
            filename = "csvs.%s.regular.tar.gz" % (tld)
            url_tld = url_base + "/" + filename
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_md5 = url_tld + ".md5"
            download_by_url(url_tld_md5, login, password, final_output_dir)

            url_tld_sha256 = url_tld + ".sha256"
            download_by_url(url_tld_sha256, login, password, final_output_dir)

            downloaded_file_names[filename] = ChecksumURLs(url_tld, url_tld_md5)
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        return 1

    #whois_database/v13/csv/tlds/full/csvs.abb.full.tar.gz
    if file_format == 'full_csv':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "full") )
        url_base = url + "/{0}/csv/tlds/full".format(version)
        print final_output_dir 

        downloaded_file_names = dict()
        for tld in tld_list:
            filename = "csvs.%s.full.tar.gz" % (tld)
            url_tld = url_base + "/" + filename 
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_md5 = url_tld + ".md5"
            download_by_url(url_tld_md5, login, password, final_output_dir)

            url_tld_sha256 = url_tld + ".sha256"
            download_by_url(url_tld_sha256, login, password, final_output_dir)

            downloaded_file_names[filename] = ChecksumURLs(url_tld, url_tld_md5)
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        return 1

    #whois_database/v13/database_dump/mysqldump/abb/whoiscrawler_v13_abb_mysql.sql.gz
    #whois_database/v13/database_dump/mysqldump/abb/whoiscrawler_v13_abb_mysql_schema.sql.gz
    if file_format == 'mysqldump':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "mysqldump") )
        if( version in ['v1','v2'] ):
            check_sum_dict = dict()
            print final_output_dir 
            url_tld = url + '/{0}/database_dump'.format(version)

            csv_name = "contact_mysql.sql.gz" 
            contact_mysql_url = url_tld + "/" + csv_name
            download_by_url(contact_mysql_url, login, password, final_output_dir)
            contact_mysql_md5_url = contact_mysql_url + ".md5"
            download_by_url(contact_mysql_md5_url, login, password, final_output_dir)
            contact_mysql_sha256_url = contact_mysql_url + ".sha256"
            download_by_url(contact_mysql_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(contact_mysql_url, contact_mysql_md5_url)

            csv_name = "registry_data_mysql.sql.gz" 
            registry_mysql_url = url_tld + "/" + csv_name
            download_by_url(registry_mysql_url, login, password, final_output_dir)
            registry_mysql_md5_url = registry_mysql_url + ".md5"
            download_by_url(registry_mysql_md5_url, login, password, final_output_dir)
            registry_mysql_sha256_url = registry_mysql_url + ".sha256"
            download_by_url(registry_mysql_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(registry_mysql_url, registry_mysql_md5_url)

            whois_filename_base = "whois" if version == 'v1' else "whois2"

            csv_name = whois_filename_base + "_mssql.sql.gz"
            whois_mssql_url = url_tld + "/" + csv_name
            download_by_url(whois_mssql_url, login, password, final_output_dir)
            whois_mssql_md5_url = whois_mssql_url + ".md5"
            download_by_url(whois_mssql_md5_url, login, password, final_output_dir)
            whois_mssql_sha256_url = whois_mssql_url + ".sha256"
            download_by_url(whois_mssql_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(whois_mssql_url, whois_mssql_md5_url)

            csv_name = whois_filename_base + ".sql.gz"
            whois_sql_url = url_tld + "/" + csv_name
            download_by_url(whois_sql_url, login, password, final_output_dir)
            whois_sql_md5_url = whois_sql_url + ".md5"
            download_by_url(whois_sql_md5_url, login, password, final_output_dir)
            whois_sql_sha256_url = whois_sql_url + ".sha256"
            download_by_url(whois_sql_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(whois_sql_url, whois_sql_md5_url)
            
            csv_name = whois_filename_base + "_record_mysql.sql.gz"
            whois_record_url = url_tld + "/" + csv_name
            download_by_url(whois_record_url, login, password, final_output_dir)
            whois_record_md5_url = whois_record_url + ".md5"
            download_by_url(whois_record_md5_url, login, password, final_output_dir)
            whois_record_sha256_url = whois_record_url + ".sha256"
            download_by_url(whois_record_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(whois_record_url, whois_record_md5_url)

            # Check file integrity
            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_tld, login, password, interactive, check_sum_dict )

        else:
            for tld in tld_list:
                check_sum_dict = dict()
                final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "mysqldump", tld) )
                table_final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "mysqldump", tld, "tables") )
                url_base = url + "/%s/database_dump/mysqldump/%s" % (version, tld)

                correct_tld_format = tld.replace(".", "_")
                csv_name = 'whoiscrawler_%s_%s_mysql.sql.gz' % (version, tld)
                url_tld = url_base + '/' + csv_name
                print final_output_dir 
                download_by_url(url_tld, login, password, final_output_dir)
                url_tld_md5 = url_tld + ".md5"
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_tld + ".sha256"
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_tld_md5)

                csv_name = 'whoiscrawler_%s_%s_mysql_schema.sql.gz' % (version, tld)
                url_tld = url_base + '/' + csv_name
                print final_output_dir 
                download_by_url(url_tld, login, password, final_output_dir)
                url_tld_md5 = url_tld + ".md5"
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_tld + ".sha256"
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_tld_md5)

                check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, check_sum_dict )

                # Download Tables 
                url_table_base = url_base + "/tables"

                csv_name = "whoiscrawler_%s_%s_contact_mysql.sql.gz" % (version, correct_tld_format) 
                url_file = url_table_base + "/" + csv_name
                download_by_url(url_file, login, password, table_final_output_dir)
                url_tld_md5 = url_file + ".md5"
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_file + ".sha256"
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_file, url_tld_md5)

                csv_name = "whoiscrawler_%s_%s_domain_names_whoisdatacollector_mysql.sql.gz" % (version, correct_tld_format) 
                url_file = url_table_base + "/" + csv_name
                download_by_url(url_file, login, password, table_final_output_dir)
                url_tld_md5 = url_file + ".md5"
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_file + ".sha256"
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_file, url_tld_md5)

                csv_name = "whoiscrawler_%s_%s_registry_data_mysql.sql.gz" % (version, correct_tld_format) 
                url_file = url_table_base + "/" + csv_name
                download_by_url(url_file, login, password, table_final_output_dir)
                url_tld_md5 = url_file + ".md5"
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_file + ".sha256"
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_file, url_tld_md5)

                csv_name = "whoiscrawler_%s_%s_whois_record_mysql.sql.gz" % (version, correct_tld_format) 
                url_file = url_table_base + "/" + csv_name
                download_by_url(url_file, login, password, table_final_output_dir)
                url_tld_md5 = url_file + ".md5"
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_file + ".sha256"
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_file, url_tld_md5)

                # Check each tld
                check_redownload_if_bad_checksums( dfeed, table_final_output_dir, url_table_base, login, password, interactive, check_sum_dict )

        return 1

    return 0

def download_domain_list_quarterly(url, login, password, file_format, version, interactive,
                                    tld_list,  output_dir = os.path.join(WORKDIR, "data" ) ):
    url_tld = ''
    dfeed = 'domain_list_quarterly'
    #['regular_csv', 'full_csv', 'mysqldump']

    #domain_list_quarterly/v3/csv/tlds/simple/csvs.jp.simple.tar.gz
    print
    if file_format == 'docs':
	url_base = url + "/%s/docs" % (version)
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "docs") )
	# Download .tlds
	url_tlds = url_base + "/%s.tlds" % (version)
	download_by_url(url_tlds, login, password, final_output_dir)

	# Download Scripts	
        download_script_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "docs", "download_scripts") )
        url_download_scripts_base = url_base + "/download_scripts"

        url_bash_base = url_download_scripts_base + "/bash"
        final_output_dir = os.path.abspath( os.path.join(download_script_dir, "bash") )
        url_bash_make = url_bash_base + "/Makefile"
	download_by_url(url_bash_make, login, password, final_output_dir)

        url_bash_readme = url_bash_base + "/README"
	download_by_url(url_bash_readme, login, password, final_output_dir)

        url_bash_ft = url_bash_base + "/ft_whoisdownload"
	download_by_url(url_bash_ft, login, password, final_output_dir)

        url_bash_sup_gtlds = url_bash_base + "/supported_gtlds"
	download_by_url(url_bash_sup_gtlds, login, password, final_output_dir)

        url_bash_sup_ngtlds = url_bash_base + "/supported_ngtlds"
	download_by_url(url_bash_sup_ngtlds, login, password, final_output_dir)

        url_bash_tlds = url_bash_base + "/tlds-01.text"
	download_by_url(url_bash_tlds, login, password, final_output_dir)

        url_bash_ut_whois_download = url_bash_base + "/ut_whoisdownload"
	download_by_url(url_bash_ut_whois_download, login, password, final_output_dir)

        url_bash_whois_download = url_bash_base + "/whoisdownload.sh"
	download_by_url(url_bash_whois_download, login, password, final_output_dir)

        url_python_base = url_download_scripts_base + "/python"
        final_output_dir = os.path.abspath( os.path.join(download_script_dir, "python") )
        url_python_readme = url_python_base + "/README"
	download_by_url(url_python_readme, login, password, final_output_dir)

        url_python_config = url_python_base + "/config.ini"
	download_by_url(url_python_config, login, password, final_output_dir)

        url_python_downloader = url_python_base + "/get_whois_info.py"
	download_by_url(url_python_downloader, login, password, final_output_dir)

        url_python_sup_gtlds = url_python_base + "/supported_gtlds"
	download_by_url(url_python_sup_gtlds, login, password, final_output_dir)

        url_python_sup_ngtlds = url_python_base + "/supported_ngtlds"
	download_by_url(url_python_sup_ngtlds, login, password, final_output_dir)

        return 1

    if file_format == 'readme':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version) )
	url_readme = url + "/%s/README.txt" % (version)
	download_by_url(url_readme, login, password, final_output_dir)

        return 1

    if file_format in ['simple_csv', 'regular_csv', 'full_csv']:
        correct_file_name = file_format.split("_")[0]
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, correct_file_name) )
        url_base = url + "/%s/csv/tlds/%s" % (version, correct_file_name)

        downloaded_file_names = dict()
        for tld in tld_list:
            filename = "csvs.%s.%s.tar.gz" % (tld, correct_file_name)
            url_tld = url_base + "/" + filename
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_md5 = url_tld + ".md5"
            download_by_url(url_tld_md5, login, password, final_output_dir)

            url_tld_sha256 = url_tld + ".sha256"
            download_by_url(url_tld_sha256, login, password, final_output_dir)

            # Add file to dict
            downloaded_file_names[filename] = ChecksumURLs(url_tld, url_tld_md5)


        check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        return 1

    if file_format == 'mysqldump':
        for tld in tld_list:
            check_sum_dict = dict()
            final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "mysqldump", tld) )
            table_final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "mysqldump", tld, "tables") )
            url_base = url + "/%s/database_dump/mysqldump/%s" % (version, tld)

            correct_tld_format = tld.replace(".", "_")

            csv_name = 'domains_whoiscrawler_%s_%s_mysql.sql.gz' % (version, correct_tld_format)
            url_tld = url_base + '/' + csv_name
            #final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "mysqldump") )
            download_by_url(url_tld, login, password, final_output_dir)
            url_tld_md5 = url_tld + ".md5"
            download_by_url(url_tld_md5, login, password, final_output_dir)
            url_tld_sha256 = url_tld + ".sha256"
            download_by_url(url_tld_sha256, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_tld_md5)

            csv_name = 'domains_whoiscrawler_%s_%s_mysql_schema.sql.gz' % (version, correct_tld_format)
            url_tld = url_base + '/' + csv_name
            download_by_url(url_tld, login, password, final_output_dir)
            url_tld_md5 = url_tld + ".md5"
            download_by_url(url_tld_md5, login, password, final_output_dir)
            url_tld_sha256 = url_tld + ".sha256"
            download_by_url(url_tld_sha256, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_tld_md5)
            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, check_sum_dict )

            # Download Tables 
            url_table_base = url_base + "/tables"
            csv_name = "domains_whoiscrawler_%s_%s_contact_mysql.sql.gz" % (version, correct_tld_format)
            url_file = url_table_base + "/" + csv_name
            download_by_url(url_file, login, password, table_final_output_dir)
            url_file_md5 = url_file + ".md5"
            download_by_url(url_file_md5, login, password, table_final_output_dir)
            url_file_sha256 = url_file + ".sha256"
            download_by_url(url_file_sha256, login, password, table_final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_file, url_file_md5)


            csv_name = "domains_whoiscrawler_%s_%s_domain_names_whoisdatacollector_mysql.sql.gz" % (version, correct_tld_format)
            url_file = url_table_base + "/" + csv_name
            download_by_url(url_file, login, password, table_final_output_dir)
            url_file_md5 = url_file + ".md5"
            download_by_url(url_file_md5, login, password, table_final_output_dir)
            url_file_sha256 = url_file + ".sha256"
            download_by_url(url_file_sha256, login, password, table_final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_file, url_file_md5)

            csv_name = "domains_whoiscrawler_%s_%s_registry_data_mysql.sql.gz" % (version, correct_tld_format)
            url_file = url_table_base + "/" + csv_name
            download_by_url(url_file, login, password, table_final_output_dir)
            url_file_md5 = url_file + ".md5"
            download_by_url(url_file_md5, login, password, table_final_output_dir)
            url_file_sha256 = url_file + ".sha256"
            download_by_url(url_file_sha256, login, password, table_final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_file, url_file_md5)

            csv_name = "domains_whoiscrawler_%s_%s_whois_record_mysql.sql.gz" % (version, correct_tld_format)
            url_file = url_table_base + "/" + csv_name
            download_by_url(url_file, login, password, table_final_output_dir)
            url_file_md5 = url_file + ".md5"
            download_by_url(url_file_md5, login, password, table_final_output_dir)
            url_file_sha256 = url_file + ".sha256"
            download_by_url(url_file_sha256, login, password, table_final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_file, url_file_md5)

            # Check each tld
            check_redownload_if_bad_checksums( dfeed, table_final_output_dir, url_table_base, login, password, interactive, check_sum_dict )
            
        return 1

    return 0


"""
===========================================
Obtains supported tld for a daily data feed
===========================================
"""
# Purpose: Download TLDs list for feed if needed
# Set dfeed_url for daily data. Quarterly release will override this variable.
# Makes it easier to generate daily data-feed urls

def getDataFeedURL(dfeed_type):
    # QUARTERLY
    if(dfeed_type in ["whois_database", "domain_list_quarterly"]):
        dfeed_url = getQuarterlyGtldUrl() if dfeed_type in ['whois_database'] else getQuarterlyCctldUrl()

    # DAILY NGTLD
    elif( dfeed_type in ["ngtld_newly_registered_domains"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_new") 
    elif( dfeed_type in ["ngtld_whois_data"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_whois") 
    elif( dfeed_type in ["ngtld_whois_data_archive"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_whois_archive") 
    elif( dfeed_type in ["ngtld_recently_dropped_domains"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_dropped") 
    elif( dfeed_type in ["ngtld_recently_dropped_whois_domains"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_dropped_whois") 
    elif( dfeed_type in ["ngtld_domain_names_whois_filtered_reg_country"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_whois_filtered_reg_country") 
    elif( dfeed_type in ["ngtld_domain_names_whois_filtered_reg_country_noproxy"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_whois_filtered_reg_country_noproxy") 
    elif( dfeed_type in ["ngtld_domain_names_whois_filtered_reg_country_archive"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_whois_filtered_reg_country_archive") 
    elif( dfeed_type in ["ngtld_domain_names_whois_filtered_reg_country_noproxy_archive"] ):
        dfeed_url = getDailyNGtldUrl("domain_names_whois_filtered_reg_country_noproxy_archive") 

    # DAILY CCTLD
    elif(dfeed_type in ["cctld_discovered_domain_names_whois"]):
        dfeed_url = getDailyCctldDiscoveredUrl("domain_names_whois")
    elif(dfeed_type in ["cctld_discovered_domain_names_new"]):
        dfeed_url = getDailyCctldDiscoveredUrl("domain_names_new")
    elif(dfeed_type in ["cctld_registered_domain_names_new", "cctld_registered_domain_names_whois", "cctld_registered_domain_names_dropped", "cctld_registered_domain_names_dropped_whois"]):
        dfeed_url = getDailyCctldRegisteredUrl(dfeed_type.replace("cctld_registered_", ""))

    # DAILY GTLD
    else:
        dfeed_url = getDailyGtldUrl(dfeed_type)

    return dfeed_url


# for getting tlds of each data feed, please first check the tld file in the following order(use the first valid one)
# regular_tlds1. $data_feed_parent_dir/status/supported_tlds_$YYYY_mm_dd
# regular_tlds2. $data_feed_parent_dir/status/supported_tlds
# ngtlds1. for ngtlds related data feeds, use http://bestwhois.org/ngtlds_domain_name_data/domain_names_whois/status/supported_tlds_$YYYY_mm_dd;
# ngtlds2. for other data feeds use http://bestwhois.org/domain_name_data/domain_names_whois/status/supported_tlds
# url_of_last_hope. $data_feed_parent_dir/supported_tlds
# d. local files(supported_ngtlds or supported_gtlds)
# and the above rules don't apply to quarterly tlds: http://www.domainwhoisdatabase.com/whois_database/v13/docs/v13.tlds
def get_tlds(dfeed_url, dfeed_type, date, login, password, version, odir):
    global WORKDIR
    tld_local_file = os.path.abspath(os.path.join(WORKDIR, 'supported_gtlds'))
    ng_tld_local_file = os.path.abspath(os.path.join(WORKDIR, 'supported_ngtlds'))
    temp_dir_for_tlds = os.path.abspath( os.path.join(WORKDIR, "temp") )
    tlds_list = []
    date = date_to_string(date) if date is not None else None
    date = date.replace('-', '_') if date is not None else None
    tlds_urls_dict = {
        "quarterly_tlds": dfeed_url + "/%s/docs/%s.tlds" % (version,version),
        "domain_list_quarterly_tlds": dfeed_url + "/{0}/docs/{1}.tlds".format(version, version),
        "tlds_link1": dfeed_url + "/status/supported_tlds_%s" % date,
        "tlds_link2": dfeed_url + "/status/supported_tlds",
        "ngtlds": "http://bestwhois.org/ngtlds_domain_name_data/domain_names_whois/status/supported_tlds_%s" % date,
        "tlds_link3": "http://bestwhois.org/domain_name_data/domain_names_whois/status/supported_tlds",
        "url_of_last_hope": dfeed_url + "/supported_tlds",
    }

    filepath_tlds = str()
    filename_tlds = str()

    print "Try to get TLD file..."

    # if there is ng tlds of data feed type than we try to get appropriate tld file:
    if version != "v0":
        if( dfeed_type == "whois_database" \
            and download_by_url(tlds_urls_dict.get("quarterly_tlds"), login, password, temp_dir_for_tlds, file_exist_check = False) ):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("quarterly_tlds")).path)

        elif(   dfeed_type == "domain_list_quarterly" \
                and download_by_url(tlds_urls_dict["domain_list_quarterly_tlds"], login, password, temp_dir_for_tlds, file_exist_check = False) ):
            print "SUCCESS"
            filename_tlds = os.path.basename( urlparse(tlds_urls_dict["domain_list_quarterly_tlds"]).path )

        else:
            print "FAIL! Cannot download quarterly tld fild versions=%s" % version
            return 0
    elif download_by_url(tlds_urls_dict.get("tlds_link1"), login, password, temp_dir_for_tlds, file_exist_check = False):
        print(tlds_urls_dict.get("tlds_link1"))
        print "SUCCESS"
        filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link1")).path)

    elif download_by_url(tlds_urls_dict.get("tlds_link2"), login, password, temp_dir_for_tlds, file_exist_check = False):
        print "SUCCESS"
        filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link2")).path)

    # For domain_names_new, we have to check the domain_names_whois feeds as last resort.
    elif("domain_names_new" in dfeed_url):
        if download_by_url(tlds_urls_dict.get("tlds_link1").replace('domain_names_new', 'domain_names_whois'), login, password, temp_dir_for_tlds, file_exist_check = False):
            print(tlds_urls_dict.get("tlds_link1"))
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link1")).path)
        elif download_by_url(tlds_urls_dict.get("tlds_link2").replace('domain_names_new', 'domain_names_whois'), login, password, temp_dir_for_tlds, file_exist_check = False):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link2")).path)

    elif dfeed_type.find("ngtld") != -1:
        print "NGTLD"
        if download_by_url(tlds_urls_dict.get("ngtlds"), login, password, temp_dir_for_tlds, file_exist_check = False):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("ngtlds")).path)
    else:
        if download_by_url(tlds_urls_dict.get("tlds_link3"), login, password, temp_dir_for_tlds, file_exist_check = False):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link3")).path)

    if filename_tlds == '':
        if download_by_url(tlds_urls_dict.get("url_of_last_hope"), login, password, temp_dir_for_tlds, file_exist_check = False):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("url_of_last_hope")).path)

    if filename_tlds == '':
        print "Cannot download appropriate tld file. Trying to get list of tlds from a local file %s" % ng_tld_local_file
        if os.path.isfile(ng_tld_local_file) == True:
            print "Have found local file %s" % ng_tld_local_file
            filepath_tlds = ng_tld_local_file
        else:
            print "FAIL! There aren't any tld lists."
            return 0
    else:
        filepath_tlds = os.path.abspath( os.path.join(WORKDIR, 'temp', filename_tlds) )


    newtlds_file = open(filepath_tlds, "r")
    for line in newtlds_file:
        line = line.rstrip('\n')
        newtlds_list = line.split(',')
        for tld in newtlds_list:
            if tld != '': tlds_list.append(tld)
    newtlds_file.close()

    print "There is list of TLDs = %s" % tlds_list
    return tlds_list


