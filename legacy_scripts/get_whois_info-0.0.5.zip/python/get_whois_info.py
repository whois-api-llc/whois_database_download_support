#!/usr/bin/env python

from collections import namedtuple
from requests.adapters import HTTPAdapter
from urlparse import urlparse
from collections import defaultdict

import argparse, ConfigParser, fnmatch, hashlib, re
import logging, os, sys, errno
import requests, time, datetime

"""
>>Future Suggestions
    - Most likely need to incoporate beautifulsoup to perform webscrape to 'download all' 
    instead of hardcoding download urls
        + Will definitely reduce the number liens of code and need for fixing in the future
"""

DEBUG = False

CURRENT_VERSION = "0.0.5"
workdir = os.path.dirname(os.path.realpath(__file__))
if( not os.path.isfile(os.path.abspath(os.path.join(workdir, 'config.ini'))) ):
    print "Missing config.ini.."
    print "Exiting."
    sys.exit(1)

config_downloader = ConfigParser.ConfigParser()
config_downloader.read( os.path.abspath(os.path.join(workdir, 'config.ini')) )

def mkdir_p(path):
    if not os.path.exists(path):
        os.makedirs(path)

# Setup logger
mkdir_p(os.path.join(workdir, "log"))
current_date = datetime.datetime.now()
logging.basicConfig(filename=os.path.join(workdir, "log", current_date.strftime("%Y_%m_%d_error") + ".log"), filemode='a', level=logging.INFO)
logging.info("========" + "Downloader started on " + current_date.strftime("%c") + "========")

# List of TLDs
TLD_list = []
NEWTLDS_url = config_downloader.get('gtld', 'NEWTLDS_url')

# List of urls with filename that is missing md5
MISSING_MD5_PATH_LIST = set()

ChecksumURLs = namedtuple('ChecksumURLs', ['file_url', 'md5_url'])
# List of data feed types
DFEED_types = ['domain_names_new',
               'domain_names_dropped',
               'domain_names_dropped_whois',
               'domain_names_whois',
               'domain_names_whois_filtered_reg_country',
               'domain_names_whois_filtered_reg_country_noproxy',
               'whois_record_delta_domain_names_change',
               'whois_record_delta_whois',
               'domain_names_whois_archive',
               'domain_names_whois_filtered_reg_country_archive',
               'domain_names_whois_filtered_reg_country_noproxy_archive',
               'ngtld_newly_registered_domains',
               'ngtld_recently_dropped_domains',
               'ngtld_recently_dropped_whois_domains',
               'ngtld_whois_data',

               'cctld_discovered_domain_names_new',
               'cctld_discovered_domain_names_whois',
               'cctld_registered_domain_names_new',
               'cctld_registered_domain_names_whois',
               'cctld_registered_domain_names_dropped',
               'cctld_registered_domain_names_dropped_whois',

               'whois_database',
               'domain_list_quarterly',
               'whois_database_combined'
]

# Available file formats
FORMATS_list = ['simple_csv', 'regular_csv', 'full_csv', 'mysqldump', 'docs', 'readme']

        
# argparse Date format check
def obtain_date_from_string( date_str ):
    """Converts string YYYY-MM-DD into a datetime object

    Parameter:
        date_str: String representing YYYY-MM-DD

    Returns:
        Datetime object
    """
    try:
        date_result = datetime.datetime.strptime( date_str, "%Y-%m-%d" )
    except(ValueError):
        raise argparse.ArgumentTypeError("Invalid date '{0}'".format(date_str))
    
    return date_result

# Preparing arguments
argparser=argparse.ArgumentParser(description='Download whois data')
argparser.add_argument('-c', '--dfeed-type', type=str, required=True, choices = DFEED_types,
                        help='a type of data_feed (see the README)')
argparser.add_argument('-l', '--login', type=str, required=True, help='User login')
argparser.add_argument('-p', '--password', type=str, required=True, help='User password')

argparser.add_argument('-d', '--date', type=obtain_date_from_string, help='Date (format YYYY-MM-DD)')
argparser.add_argument('--end-date', type=obtain_date_from_string, help='End date of data (format YYYY-MM-DD)')
# argparser.add_argument('-n', '--num-days-ahead', type = int, default = 0,
                        # help = "If provided, creates a date range from --date to (--date + n) days." )
argparser.add_argument('-v', '--version', type=str, required=False, default='v0',
                        help='It is required for data feed type "whois_database" (DEFAULT: v0)')
argparser.add_argument('-t', '--tld', nargs = "*", type=str, required=False, default= ['all'],
                        help='TLDs for downloading (DEFAULT: all). Can have tlds space delimited "com aaa aarp" ')
argparser.add_argument('-f', '--file-format', nargs="*", type=str, choices=FORMATS_list + ['all'], required=False,
                        help='File formats you want. Space delimited'.format(FORMATS_list))
argparser.add_argument('-odir', '--output-dir', type=str, 
                        default= os.path.abspath( os.path.join(workdir, 'data') ),
                        help='Output directory for downloaded files, default=' + 
                        os.path.abspath( os.path.join(workdir, 'data') ) )
argparser.add_argument( '--interactive', action = 'store_true',
        help = "Asks the user if they would like to delete parts of whois_tld_combined if checksums do not match, and redownload. Default: Deletes and redownload parts that do not match." )
argparser.add_argument('--no-override', action = 'store_true',
        help = "If provided, do not download if file already exists")

args = argparser.parse_args()

# Check end date >= start date
if(args.end_date is not None and args.end_date < args.date):
    print "End date cannot be a date before start date"
    sys.exit(1)

if( args.dfeed_type in ["whois_database", "domain_list_quarterly"] ):
    if( args.file_format is None):
        argparser.error("File format(--file-format) is required {0}".format(FORMATS_list))
    elif( args.version == "v0" ):
        argparser.error("Version (--version) is required")

# for getting tlds of each data feed, please first check the tld file in the following order(use the first valid one)
# regular_tlds1. $data_feed_parent_dir/status/supported_tlds_$YYYY_mm_dd
# regular_tlds2. $data_feed_parent_dir/status/supported_tlds
# ngtlds1. for ngtlds related data feeds, use http://bestwhois.org/ngtlds_domain_name_data/domain_names_whois/status/supported_tlds_$YYYY_mm_dd;
# ngtlds2. for other data feeds use http://bestwhois.org/domain_name_data/domain_names_whois/status/supported_tlds
# url_of_last_hope. $data_feed_parent_dir/supported_tlds
# d. local files(supported_ngtlds or supported_gtlds)
# and the above rules don't apply to quarterly tlds: http://www.domainwhoisdatabase.com/whois_database/v13/docs/v13.tlds
def get_tlds(dfeed_parent_url, dfeed_type, date, login, password, version, odir):
    global workdir
    tld_local_file = os.path.abspath(os.path.join(workdir, 'supported_gtlds'))
    ng_tld_local_file = os.path.abspath(os.path.join(workdir, 'supported_ngtlds'))
    temp_dir_for_tlds = os.path.abspath( os.path.join(workdir, "temp") )
    tlds_list = []
    date = date_to_string(date) if date is not None else None
    date = date.replace('-', '_') if date is not None else None
    tlds_urls_dict = {
        "quarterly_tlds": dfeed_parent_url + "/%s/docs/%s.tlds" % (version,version),
        "domain_list_quarterly_tlds": dfeed_parent_url + "/{0}/docs/{1}.tlds".format(version, version),
        "tlds_link1": dfeed_parent_url + "/status/supported_tlds_%s" % date,
        "tlds_link2": dfeed_parent_url + "/status/supported_tlds",
        "ngtlds": "http://bestwhois.org/ngtlds_domain_name_data/domain_names_whois/status/supported_tlds_%s" % date,
        "tlds_link3": "http://bestwhois.org/domain_name_data/domain_names_whois/status/supported_tlds",
        "url_of_last_hope": dfeed_parent_url + "/supported_tlds",
    }

    filepath_tlds = str()
    filename_tlds = str()

    print "Try to get TLD file..."

    # if there is ng tlds of data feed type than we try to get appropriate tld file:
    if version != "v0":
        if( dfeed_type == "whois_database" \
            and download_by_url(tlds_urls_dict.get("quarterly_tlds"), login, password, temp_dir_for_tlds, file_exist_check = False) ):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("quarterly_tlds")).path)

        elif(   dfeed_type == "domain_list_quarterly" \
                and download_by_url(tlds_urls_dict["domain_list_quarterly_tlds"], login, password, temp_dir_for_tlds, file_exist_check = False) ):
            print "SUCCESS"
            filename_tlds = os.path.basename( urlparse(tlds_urls_dict["domain_list_quarterly_tlds"]).path )

        else:
            print "FAIL! Cannot download quarterly tld fild versions=%s" % version
            return 0
    elif download_by_url(tlds_urls_dict.get("tlds_link1"), login, password, temp_dir_for_tlds, file_exist_check = False):
        print(tlds_urls_dict.get("tlds_link1"))
        print "SUCCESS"
        filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link1")).path)

    elif download_by_url(tlds_urls_dict.get("tlds_link2"), login, password, temp_dir_for_tlds, file_exist_check = False):
        print "SUCCESS"
        filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link2")).path)

    # For domain_names_new, we have to check the domain_names_whois feeds as last resort.
    elif("domain_names_new" in dfeed_url):
        if download_by_url(tlds_urls_dict.get("tlds_link1").replace('domain_names_new', 'domain_names_whois'), login, password, temp_dir_for_tlds, file_exist_check = False):
            print(tlds_urls_dict.get("tlds_link1"))
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link1")).path)
        elif download_by_url(tlds_urls_dict.get("tlds_link2").replace('domain_names_new', 'domain_names_whois'), login, password, temp_dir_for_tlds, file_exist_check = False):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link2")).path)

    elif dfeed_type.find("ngtld") != -1:
        print "NGTLD"
        if download_by_url(tlds_urls_dict.get("ngtlds"), login, password, temp_dir_for_tlds, file_exist_check = False):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("ngtlds")).path)
    else:
        if download_by_url(tlds_urls_dict.get("tlds_link3"), login, password, temp_dir_for_tlds, file_exist_check = False):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("tlds_link3")).path)

    if filename_tlds == '':
        if download_by_url(tlds_urls_dict.get("url_of_last_hope"), login, password, temp_dir_for_tlds, file_exist_check = False):
            print "SUCCESS"
            filename_tlds = os.path.basename(urlparse(tlds_urls_dict.get("url_of_last_hope")).path)

    if filename_tlds == '':
        print "Cannot download appropriate tld file. Try to get list of tlds from a local file %s" % ng_tld_local_file
        if os.path.isfile(ng_tld_local_file) == True:
            print "Have found local file %s" % ng_tld_local_file
            filepath_tlds = ng_tld_local_file
        else:
            print "FAIL! There aren't any tld lists."
            return 0
    else:
        filepath_tlds = os.path.abspath( os.path.join(workdir, 'temp', filename_tlds) )


    newtlds_file = open(filepath_tlds, "r")
    for line in newtlds_file:
        line = line.rstrip('\n')
        newtlds_list = line.split(',')
        for tld in newtlds_list:
            if tld != '': tlds_list.append(tld)
    newtlds_file.close()

    print "There is list of TLDs = %s" % tlds_list
    return tlds_list


def download_by_url(url, login, password, output_dir, file_exist_check = args.no_override):
    filename = os.path.basename(urlparse(url).path)
    filename = os.path.abspath(os.path.join(output_dir, filename))

    if(DEBUG): 
        print(url)
    # Make dir to output files to
    mkdir_p(output_dir)

    if( file_exist_check and os.path.isfile(filename) ):
        print "{0} already exists".format( filename )
        return True
        
    s = requests.Session()
    s.auth = (login, password)


    # Redownload file, if problem occurs with network
    while True:
        try:
            r = s.get(url, stream=True, timeout=30)

            if r.status_code == 200:
                with open(filename, 'wb') as out:
                    if( 'content-length' in (r.headers) ):
                        dl_total_length = int(r.headers.get('content-length'))
                    dl_size=0
                    dl_start_chunk = datetime.datetime.now()

                    sys.stdout.write("\r                                                    ")
                    sys.stdout.flush()
                    for chunk in r.iter_content(chunk_size=(1024*1024)):
                        out.write(chunk)
                        dl_end_chunk = datetime.datetime.now()
                        dl_size += len(chunk)
                        #if dl_start_chunk != 0 and 'content-length' in (r.headers):
                        if 'content-length' in (r.headers):
                            # dl_done = int(100 * dl_size / dl_total_length)
                            dl_done = float(dl_size) / dl_total_length
                            dl_dtdelta = ( dl_end_chunk - dl_start_chunk ).microseconds
                            # sys.stdout.write("\r%s %s" % (dl_done, str( 1024 * 60 / dl_dtdelta) ))
                            # sys.stdout.write("\r{0:.2%} {1}".format(dl_done, str( 1024 * 60 / dl_dtdelta) ))
                            sys.stdout.write("\rProgress: {0:.2%}".format(dl_done))
                            sys.stdout.flush()
                        dl_start_chunk = datetime.datetime.now()
                sys.stdout.write("\rProgress: {0:.2%}".format(1))
                sys.stdout.flush()
                print
                print "File has been downloaded successfully."
            elif r.status_code == 401:
                print "HTTP %s Unauthorized. Login credentials are wrong." % r.status_code
                try:
                    os.rmdir(output_dir);
                except OSError:
                    pass

                sys.exit(1)
                return False
            else:
                print "Error HTTP %s File Not Found" % r.status_code
                print
                try:
                    os.rmdir(output_dir);
                except OSError:
                    pass
                return False
            print ""

            return True
        except requests.exceptions.Timeout or requests.exceptions.ConnectionError:
            sys.stdout.write("\rNetwork timed out. Attempting redownload..")
            sys.stdout.flush()
            time.sleep(4)
            continue
        except requests.exceptions.ConnectionError or requests.exceptions.ChunkedEncodingError:
            sys.stdout.write("\rNetwork timed out. Attempting redownload..")
            sys.stdout.flush()
            time.sleep(4)
            continue
        except requests.exceptions.ChunkedEncodingError:
            sys.stdout.write("\rChunked Encoding Error. Redownloading")
            sys.stdout.flush()
            time.sleep(4)
            continue


def date_to_string( datetime_obj ):
    """Converts a datetime object into the proper string format for downloading
    
    Parameters:
        datetime_obj: datetime object

    Returns:
        Date as a string in the format of YYYY-MM-DD
    """
    return datetime_obj.strftime( "%Y-%m-%d" )


def daily_download_readme( url, login, password, output_dir = os.path.abspath(os.path.join(".", "data"))):
    """
    Downloads the README for each daily data
    """
    if( not os.path.isfile(os.path.abspath(os.path.join(output_dir, "README"))) ):
        url_readme = url + "/" + "README"
        print url_readme
        download_by_url(url_readme, login, password, output_dir)


#$tld/yyyy-MM-dd/add.$tld.csv
#for example, if you want to get newly registered .com domain names on November 25th, 2013, the corresponding file is
#com/2013-11-25/add.com.csv
def download_domain_names_new(url, date, login, password, tld_list=TLD_list, end_date = None, interactive = False, output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_new'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    # print tld_list
    print

    # Download Readme if it does not exist already
    if("ngtld" in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "ngtlds_domain_name_data" , "domain_names_new"))
    elif('cctld_domain_name_data' in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "cctld_domain_name_data", "domain_names_new"))
    elif('domain_name_data' in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_name_data", "domain_names_new"))
    else:
        final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_list", "domain_names_new") )

    daily_download_readme( url, login, password, final_output_dir )
    # Hashes base url
    url_hash_base = url + "/hashes"

    while( cur_date <= end_date ):
        check_sum_dict = dict()
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)

            # Daily cctld has a different format
            if('domain_list' in url):
                url_base_dir = url + "/" + formatted_date
            elif('cctld_domain_name_data' in url):
                url_base_dir = url + "/" + formatted_date
            else:
                url_base_dir = url + "/" + tld + "/" + formatted_date

            if("ngtld" in url):
                final_output_dir = os.path.abspath(os.path.join(output_dir, "ngtlds_domain_name_data" , "domain_names_new", tld, formatted_date))
            elif('cctld_domain_name_data' in url):
                final_output_dir = os.path.abspath(os.path.join(output_dir, "cctld_domain_name_data", "domain_names_new", formatted_date))
            elif('domain_name_data' in url):
                final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_name_data", "domain_names_new", tld, formatted_date))
            else:
                final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_list", "domain_names_new",formatted_date) )

            # If daily cctld, file format is different
            if('domain_list' in url):
                csv_name = tld
            else:
                csv_name = "add.%s.csv" % tld

            print final_output_dir 
            url_tld = url_base_dir + "/" + csv_name 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + formatted_date + "_" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base_dir, login, password, interactive, check_sum_dict )
        cur_date = cur_date + datetime.timedelta( days = 1 )

    return 1


#$tld/yyyy-MM-dd/dropped.$tld.csv
#for example, if	you want to get	newly dropped .com domain names on November 25th, 2013, the corresponding file is
#com/2013-11-25/dropped.com.csv
def download_domain_names_dropped(url, date, login, password, tld_list=TLD_list, end_date = None, interactive = False, 
        output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_dropped'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download README
    if("ngtld" in url):
        final_output_dir = os.path.abspath(os.path.join(output_dir,  
                "ngtlds_domain_name_data", "domain_names_dropped"))
    elif("cctld_domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "cctld_domain_name_data", "domain_names_dropped") )
    elif("domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", "domain_names_dropped") )

    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"

    while( cur_date <= end_date ):
        check_sum_dict = dict()
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            if("ngtld" in url):
                final_output_dir = os.path.abspath(os.path.join(output_dir,  
                        "ngtlds_domain_name_data", "domain_names_dropped", tld, formatted_date))
            elif("cctld_domain_name_data" in url):
                final_output_dir = os.path.abspath( os.path.join(output_dir, "cctld_domain_name_data", "domain_names_dropped", formatted_date) )
            elif("domain_name_data" in url):
                final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", "domain_names_dropped", tld, formatted_date) )


            # cctld_domain_name_data formats differently
            if("cctld_domain_name_data" in url):
                url_base_dir = url + "/" + formatted_date
            else:
                url_base_dir = url + "/" + tld + "/" + formatted_date

            csv_name = "dropped.%s.csv" % tld
            url_tld = url_base_dir + "/" + csv_name 
            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + formatted_date + "_" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)

            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base_dir, login, password, interactive, check_sum_dict )
        cur_date = cur_date + datetime.timedelta( days = 1 )

    return 1


def download_domain_names_dropped_whois(url, date, login, password, file_format, tld_list=TLD_list, 
                                end_date = None,
                                interactive = False,
                                output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_dropped_whois'
    #['regular_csv', 'full_csv', 'mysqldump']

    cur_date = date

    if(end_date is None):
        end_date = cur_date
    
    print
    #yyyy_MM_dd_$tld.csv.gz
    if("ngtld" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "ngtlds_domain_name_data", dfeed) )
    elif("cctld_domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "cctld_domain_name_data", dfeed) )
    elif("domain_name_data" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )


    # Hashes base url
    url_hash_base = url + "/hashes"

    if(file_format in ['regular_csv', 'full_csv']):
        csv_check_dict = dict()
        while( cur_date <= end_date ):
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')

                if(file_format == 'regular_csv'):
                    csv_name = "%s_%s.csv.gz" % (formatted_date, tld)
                elif(file_format == 'full_csv'):
                    csv_name = "full_%s_%s.csv.gz" % (formatted_date, tld)

                url_tld = url + "/" + csv_name 
                print final_output_dir 
                print url_tld
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                print url_md5
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                print url_sha256
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1


    #add_mysqldump_yyyy_MM_dd/$tld/add_mysqldump_yyyy_MM_dd_$tld.sql.gz
    if file_format == 'mysqldump':
        while( cur_date <= end_date ):
            csv_check_dict = dict()
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')
                csv_name = 'dropped_mysqldump_%s_%s.sql.gz' % (formatted_date, tld)

                url_tld = url + '/dropped_mysqldump_%s/%s/' % (formatted_date, tld) + csv_name
                print final_output_dir 
                print url_tld
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                print url_md5
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                print url_sha256
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)
            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1

    return 0

def download_domain_names_whois_filtered_reg_country( url, date, login, password, tld_list=TLD_list,
                                                     end_date = None, interactive = False, output_dir= os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_whois_filtered_reg_country'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print
    #filtered_reg_country_2015_09_10_aero.tar.gz

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"

    csv_check_dict = dict()
    while( cur_date <= end_date ):
        formatted_date = date_to_string(cur_date)
        formatted_date = formatted_date.replace('-', '_')
        for tld in tld_list:
            csv_name = "filtered_reg_country_%s_%s.tar.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name 

            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)

            # Generate file checksum data for integrity checker
            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_domain_names_whois_filtered_reg_country_noproxy(url, date, login, password, tld_list=TLD_list,
                                                             end_date = None, 
                                                             interactive = False,
                                                             output_dir = os.path.abspath(os.path.join( ".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_whois_filtered_reg_country_noproxy'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"

    #filtered_reg_country_noproxy_2015_11_18_org.tar.gz

    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            csv_name = "filtered_reg_country_noproxy_%s_%s.tar.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)

            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_whois_record_delta_domain_names_change(url, date, login, password, tld_list=TLD_list,
                                                    end_date = None, interactive = False,
                                                    output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'whois_record_delta_domain_names_change'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"
    #auto/2015_11_11/auto.csv
    while( cur_date <= end_date ):
        check_sum_dict = dict()
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed, tld, formatted_date) )

            url_base = url + "/%s/%s" % (tld, formatted_date)
            csv_name = "%s.csv" % (tld)
            url_tld = url_base + "/" + csv_name 
            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + formatted_date + "_" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)

            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, check_sum_dict )
        cur_date = cur_date + datetime.timedelta( days = 1 )

    return 1

def download_whois_record_delta_whois(url, date, login, password, tld_list=TLD_list,
                                    end_date = None, interactive = False,
                                    output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'whois_record_delta_whois'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"
    #2015_11_15_gmo.csv.gz
    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            csv_name = "%s_%s.csv.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)

            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_domain_names_whois_archive(url, date, login, password, tld_list=TLD_list,
                                        end_date = None,
                                        interactive = False,
                                        output_dir = os.path.abspath(os.path.join(".", "data")) ):
    url_tld = ''
    dfeed = 'domain_names_whois_archive'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    # Download README if not present
    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )
    daily_download_readme( url, login, password, final_output_dir )

    # Hashes base url
    url_hash_base = url + "/hashes"

    #2013_05_09_net.csv.gz
    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            
            csv_name = "%s_%s.csv.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)
            
            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )

    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
    return 1


def download_domain_names_whois_filtered_reg_country_archive(url, date, login, password, tld_list=TLD_list,
                                                             end_date = None, 
                                                             interactive = False,
                                                             output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_whois_filtered_reg_country_archive'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    print

    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed) )

    # Hashes base url
    url_hash_base = url + "/hashes"

    #filtered_reg_country_2015_07_28_us.tar.gz
    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            
            csv_name = "filtered_reg_country_%s_%s.tar.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)

            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_domain_names_whois_filtered_reg_country_noproxy_archive(url, date, login, password, tld_list=TLD_list,
                                                                     end_date = None, 
                                                                     interactive = False,
                                                                     output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_whois_filtered_reg_country_archive'

    cur_date = date

    if(end_date is None):
        end_date = cur_date

    final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", "domain_names_whois_filtered_reg_country_noproxy_archive") )

    # Hashes base url
    url_hash_base = url + "/hashes"

    #filtered_reg_country_noproxy_2013_01_01_coop.tar.gz
    csv_check_dict = dict()
    while( cur_date <= end_date ):
        for tld in tld_list:
            formatted_date = date_to_string(cur_date)
            formatted_date = formatted_date.replace('-', '_')
            
            csv_name = "filtered_reg_country_noproxy_%s_%s.tar.gz" % (formatted_date, tld)

            url_tld = url + "/" + csv_name
            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_checksum_base = url_hash_base + "/" + csv_name
            url_md5 = url_tld_checksum_base + ".md5"
            print url_md5
            download_by_url(url_md5, login, password, final_output_dir)

            url_sha256 = url_tld_checksum_base + ".sha256"
            print url_sha256
            download_by_url(url_sha256, login, password, final_output_dir)

            csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

        cur_date = cur_date + datetime.timedelta( days = 1 )
    check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )

    return 1


def download_domain_names_whois(url, date, login, password, file_format, tld_list=TLD_list, 
                                end_date = None,
                                interactive = False,
                                output_dir = os.path.abspath(os.path.join(".", "data"))):
    url_tld = ''
    dfeed = 'domain_names_whois'
    #['regular_csv', 'full_csv', 'mysqldump']

    cur_date = date

    if(end_date is None):
        end_date = cur_date
    
    print
    #yyyy_MM_dd_$tld.csv.gz
    if("ngtld" in url):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "ngtlds_domain_name_data", dfeed))
    elif( "cctld_domain_name_data" in url ):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "cctld_domain_name_data", dfeed))
    elif( "domain_name_data" in url ):
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_name_data", dfeed))
    else:
        final_output_dir = os.path.abspath(os.path.join(output_dir, "domain_list", dfeed))

    # Hashes base url
    url_hash_base = url + "/hashes"

    if(file_format in ['regular_csv', 'full_csv']):
        csv_check_dict = dict()
        while( cur_date <= end_date ):
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')

                if(file_format == 'regular_csv'):
                    csv_name = "%s_%s.csv.gz" % (formatted_date, tld)
                elif(file_format == 'full_csv'):
                    csv_name = "full_%s_%s.csv.gz" % (formatted_date, tld)

                url_tld = url + "/" + csv_name 
                print final_output_dir 
                print url_tld
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                print url_md5
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                print url_sha256
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)

            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1

    #add_mysqldump_yyyy_MM_dd/$tld/add_mysqldump_yyyy_MM_dd_$tld.sql.gz
    if file_format == 'mysqldump':
        while( cur_date <= end_date ):
            csv_check_dict = dict()
            for tld in tld_list:
                formatted_date = date_to_string(cur_date)
                formatted_date = formatted_date.replace('-', '_')
                csv_name = 'add_mysqldump_%s_%s.sql.gz' % (formatted_date, tld)

                url_tld = url + '/add_mysqldump_%s/%s/' % (formatted_date, tld) + csv_name
                print final_output_dir 
                print url_tld
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_checksum_base = url_hash_base + "/" + csv_name
                url_md5 = url_tld_checksum_base + ".md5"
                print url_md5
                download_by_url(url_md5, login, password, final_output_dir)

                url_sha256 = url_tld_checksum_base + ".sha256"
                print url_sha256
                download_by_url(url_sha256, login, password, final_output_dir)
                csv_check_dict[csv_name] = ChecksumURLs(url_tld, url_md5)
            cur_date = cur_date + datetime.timedelta( days = 1 )
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url, login, password, interactive, csv_check_dict )
        return 1

    return 0


def download_whois_database_combined(url, login, password, file_format, version, interactive,
                            output_dir= os.path.join( workdir, "data" )):
    url_tld = ''
    end_range = 10000
    #['simple_csv', 'regular_csv', 'full_csv', 'mysqldump']
    print
    #whois_database/v13/csv/tlds/regular/csvs.abb.regular.tar.gz
    if( file_format in ['simple_csv', 'regular_csv', 'full_csv', 'mysqldump'] ):
        file_format_correct = file_format.split("_")[0]
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, 'whois_database_combined', file_format_correct) )

        # Check file existence before redownloading.
        # Starts on the last downloaded
        last_downloaded = 0
        if( os.path.isdir(final_output_dir) ):
            for i in range( 0, end_range):
                if( os.path.isfile(os.path.join(final_output_dir, "{0}-{1}.tar.gz.{2:04d}".format(file_format_correct, version, i))) ):
                    last_downloaded = i
                else:
                    break

        # Debug for loop
        # for i in range(0, 1):
        print "Starting download on part {0:04d}".format( last_downloaded )
        print final_output_dir 
        print

        for i in range(last_downloaded, end_range):
            if( file_format == "mysqldump" ):
                url_part = url + "/{0}/database_dump/mysqldump_combined/{1}-{0}.tar.gz.{2:04d}".format(version, file_format_correct, i)
            else:
                url_part = url + "/{0}/csv/tlds_combined/{1}-{0}.tar.gz.{2:04d}".format(version, file_format_correct, i)
            url_md5 = url_part + ".md5"
            url_sha = url_part + ".sha256" 

            print url_md5
            if( not download_by_url(url_md5, login, password, final_output_dir) ):
                break

            print url_sha
            if( not download_by_url(url_sha, login, password, final_output_dir) ):
                break
            
            print url_part
            if( not download_by_url(url_part, login, password, final_output_dir) ):
                break

        print "Checking file integrity.."
        bad_files = check_each_combined_tld_part(final_output_dir, interactive)
        bad_file_max_check_3 = defaultdict(int)
        while( len(bad_files) > 0 ):
            file_format_correct = file_format.split("_")[0]
            final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, 'whois_database_combined', file_format_correct) )
            print final_output_dir 
            for filename in bad_files:
                bad_file_max_check_3[filename] += 1
                if( file_format == "mysqldump" ):
                    url_part = url + "/{0}/database_dump/mysqldump_combined/{1}".format(version, filename)
                else:
                    url_part = url + "/{0}/csv/tlds_combined/{1}".format(version, filename)
                url_md5 = url_part + ".md5"
                url_sha = url_part + ".sha256" 

                print url_md5
                if( not download_by_url(url_md5, login, password, final_output_dir) ):
                    break

                print url_sha
                if( not download_by_url(url_sha, login, password, final_output_dir) ):
                    break
                
                print url_part
                if( not download_by_url(url_part, login, password, final_output_dir) ):
                    break

            print "Checking file integrity.."
            bad_files = check_each_combined_tld_part(final_output_dir, interactive)

            for fn in list(bad_files):
                if(bad_file_max_check_3[fn] > 3):
                    bad_files.remove(fn)
                    logging.error("Whois database aggregate file {0} has failed md5 check 3 times.".format(fn))


        print "File integrity checker complete."

        return True

    return False


def download_whois_database(url, login, password, file_format, version, interactive = False,
        tld_list=TLD_list, output_dir= os.path.join( workdir, "data" ) ):
    """
    Possible enhancements:
        Somehow generate one loop to handle downloading of all data instead of it being so hardcoded.
    """
    dfeed = 'whois_database'
    url_tld = ''
    #['simple_csv', 'regular_csv', 'full_csv', 'mysqldump']

    print
    #whois_database/v17/docs/
    if file_format == 'docs':
	# Download countries file
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "docs") )
	url_base = url + "/%s/docs" % (version)
	url_countries = url_base + "/countries"
	print url_countries
	download_by_url(url_countries, login, password, final_output_dir)

	# Download .tlds
	url_tlds = url_base + "/%s.tlds" % (version)
	print url_tlds
	download_by_url(url_tlds, login, password, final_output_dir)

	# Download csv scehma
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "docs", "csv", "schema") )
	url_schema_base = url_base + "/csv/schema"
	url_load_into_db = url_schema_base + "/load_csv_file_into_db.sh"
	print url_load_into_db
	download_by_url(url_load_into_db, login, password, final_output_dir)

	url_loader_full = url_schema_base + "/loader_schema_full.sql"
	print url_loader_full
	download_by_url(url_loader_full, login, password, final_output_dir)

	url_loader_reg_daily = url_schema_base + "/loader_schema_regular_daily.sql"
	print url_loader_reg_daily
	download_by_url(url_loader_reg_daily, login, password, final_output_dir)

	url_loader_reg_quarterly = url_schema_base + "/loader_schema_regular_quarterly.sql"
	print url_loader_reg_quarterly
	download_by_url(url_loader_reg_quarterly, login, password, final_output_dir)

	url_loader_simple = url_schema_base + "/loader_schema_simple.sql"
	print url_loader_reg_quarterly
	download_by_url(url_loader_simple, login, password, final_output_dir)

	# Download Scripts	
        download_script_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "docs", "download_scripts") )
        url_download_scripts_base = url_base + "/download_scripts"

        url_bash_base = url_download_scripts_base + "/bash"
        final_output_dir = os.path.abspath( os.path.join(download_script_dir, "bash") )
        url_bash_make = url_bash_base + "/Makefile"
        print url_bash_make
	download_by_url(url_bash_make, login, password, final_output_dir)

        url_bash_readme = url_bash_base + "/README"
        print url_bash_readme
	download_by_url(url_bash_readme, login, password, final_output_dir)

        url_bash_ft = url_bash_base + "/ft_whoisdownload"
        print url_bash_ft
	download_by_url(url_bash_ft, login, password, final_output_dir)

        url_bash_sup_gtlds = url_bash_base + "/supported_gtlds"
        print url_bash_sup_gtlds
	download_by_url(url_bash_sup_gtlds, login, password, final_output_dir)

        url_bash_sup_ngtlds = url_bash_base + "/supported_ngtlds"
        print url_bash_sup_ngtlds
	download_by_url(url_bash_sup_ngtlds, login, password, final_output_dir)

        url_bash_tlds = url_bash_base + "/tlds-01.text"
        print url_bash_tlds
	download_by_url(url_bash_tlds, login, password, final_output_dir)

        url_bash_ut_whois_download = url_bash_base + "/ut_whoisdownload"
        print url_bash_ut_whois_download
	download_by_url(url_bash_ut_whois_download, login, password, final_output_dir)

        url_bash_whois_download = url_bash_base + "/whoisdownload.sh"
        print url_bash_whois_download
	download_by_url(url_bash_whois_download, login, password, final_output_dir)

        url_python_base = url_download_scripts_base + "/python"
        final_output_dir = os.path.abspath( os.path.join(download_script_dir, "python") )
        url_python_readme = url_python_base + "/README"
        print url_python_readme
	download_by_url(url_python_readme, login, password, final_output_dir)

        url_python_config = url_python_base + "/config.ini"
        print url_python_config
	download_by_url(url_python_config, login, password, final_output_dir)

        url_python_downloader = url_python_base + "/get_whois_info.py"
        print url_python_downloader
	download_by_url(url_python_downloader, login, password, final_output_dir)

        url_python_sup_gtlds = url_python_base + "/supported_gtlds"
        print url_python_sup_gtlds
	download_by_url(url_python_sup_gtlds, login, password, final_output_dir)

        url_python_sup_ngtlds = url_python_base + "/supported_ngtlds"
        print url_python_sup_ngtlds
	download_by_url(url_python_sup_ngtlds, login, password, final_output_dir)

        # Download mysql scripts
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "docs", "mysql") )
        mysql_base_url = url_base + "/mysql"

        url_file = mysql_base_url + "/load_mysql_data_all.sh"
        print url_file
        download_by_url(url_file, login, password, final_output_dir)

        url_file = mysql_base_url + "/load_mysql_data_all_for_all_tlds.sh"
        print url_file
        download_by_url(url_file, login, password, final_output_dir)

        url_file = mysql_base_url + "/load_mysql_data_all_for_tld.sh"
        print url_file
        download_by_url(url_file, login, password, final_output_dir)

        url_file = mysql_base_url + "/load_mysql_data_per_tables.sh"
        print url_file
        download_by_url(url_file, login, password, final_output_dir)
         

        url_file = mysql_base_url + "/load_mysql_data_per_tables_for_all_tlds.sh"
        print url_file
        download_by_url(url_file, login, password, final_output_dir)

        url_file = mysql_base_url + "/load_mysql_data_per_tables_for_tld.sh"
        print url_file
        download_by_url(url_file, login, password, final_output_dir)


        url_file = mysql_base_url + "/load_mysql_schema.sh"
        print url_file
        download_by_url(url_file, login, password, final_output_dir)

        return 1

    #whois_database/v17/README.txt
    if file_format == 'readme':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version) )
	url_readme = url + "/%s/README.txt" % (version)
	print url_readme
	download_by_url(url_readme, login, password, final_output_dir)
        return 1

    #whois_database/v13/csv/tlds/simple/csvs.abb.simple.tar.gz

    if file_format == 'simple_csv':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "simple") )
        downloaded_file_names = dict()
        if( version == "v2" ):
            url_base = url + "/{0}/csv".format(version)

            csv_name = "whois_v2_db_export_data_csv_simple.tar.gz"
            url_tld = url_base + "/" + csv_name
            print final_output_dir 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_md5 = url_tld + ".md5"
            print url_tld_md5
            download_by_url(url_tld_md5, login, password, final_output_dir)

            url_tld_sha256 = url_tld + ".sha256"
            print url_tld_sha256
            download_by_url(url_tld_sha256, login, password, final_output_dir)

            downloaded_file_names[csv_name] = ChecksumURLs(url_tld, url_tld_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        else:
            print final_output_dir 
            url_base = url + "/{0}/csv/tlds/simple".format(version)
            for tld in tld_list:
                filename = "csvs.%s.simple.tar.gz" % (tld)
                url_tld = url_base + "/" + filename
                print url_tld
                download_by_url(url_tld, login, password, final_output_dir)

                url_tld_md5 = url_tld + ".md5"
                print url_tld_md5
                download_by_url(url_tld_md5, login, password, final_output_dir)

                url_tld_sha256 = url_tld + ".sha256"
                print url_tld_sha256
                download_by_url(url_tld_sha256, login, password, final_output_dir)

                downloaded_file_names[filename] = ChecksumURLs(url_tld, url_tld_md5)

            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        return 1

    #whois_database/v13/csv/tlds/regular/csvs.abb.regular.tar.gz
    if file_format == 'regular_csv':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "regular") )
        url_base = url + "/{0}/csv/tlds/regular".format(version)
        downloaded_file_names = dict()

        print final_output_dir 
        for tld in tld_list:
            filename = "csvs.%s.regular.tar.gz" % (tld)
            url_tld = url_base + "/" + filename
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_md5 = url_tld + ".md5"
            print url_tld_md5
            download_by_url(url_tld_md5, login, password, final_output_dir)

            url_tld_sha256 = url_tld + ".sha256"
            print url_tld_sha256
            download_by_url(url_tld_sha256, login, password, final_output_dir)

            downloaded_file_names[filename] = ChecksumURLs(url_tld, url_tld_md5)
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        return 1

    #whois_database/v13/csv/tlds/full/csvs.abb.full.tar.gz
    if file_format == 'full_csv':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "full") )
        url_base = url + "/{0}/csv/tlds/full".format(version)
        print final_output_dir 

        downloaded_file_names = dict()
        for tld in tld_list:
            filename = "csvs.%s.full.tar.gz" % (tld)
            url_tld = url_base + "/" + filename 
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_md5 = url_tld + ".md5"
            print url_tld_md5
            download_by_url(url_tld_md5, login, password, final_output_dir)

            url_tld_sha256 = url_tld + ".sha256"
            print url_tld_sha256
            download_by_url(url_tld_sha256, login, password, final_output_dir)

            downloaded_file_names[filename] = ChecksumURLs(url_tld, url_tld_md5)
        check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        return 1

    #whois_database/v13/database_dump/mysqldump/abb/whoiscrawler_v13_abb_mysql.sql.gz
    #whois_database/v13/database_dump/mysqldump/abb/whoiscrawler_v13_abb_mysql_schema.sql.gz
    if file_format == 'mysqldump':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "mysqldump") )
        if( version in ['v1','v2'] ):
            check_sum_dict = dict()
            print final_output_dir 
            url_tld = url + '/{0}/database_dump'.format(version)

            csv_name = "contact_mysql.sql.gz" 
            contact_mysql_url = url_tld + "/" + csv_name
            print contact_mysql_url
            download_by_url(contact_mysql_url, login, password, final_output_dir)
            contact_mysql_md5_url = contact_mysql_url + ".md5"
            print contact_mysql_md5_url
            download_by_url(contact_mysql_md5_url, login, password, final_output_dir)
            contact_mysql_sha256_url = contact_mysql_url + ".sha256"
            print contact_mysql_sha256_url
            download_by_url(contact_mysql_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(contact_mysql_url, contact_mysql_md5_url)

            csv_name = "registry_data_mysql.sql.gz" 
            registry_mysql_url = url_tld + "/" + csv_name
            print registry_mysql_url
            download_by_url(registry_mysql_url, login, password, final_output_dir)
            registry_mysql_md5_url = registry_mysql_url + ".md5"
            print registry_mysql_md5_url
            download_by_url(registry_mysql_md5_url, login, password, final_output_dir)
            registry_mysql_sha256_url = registry_mysql_url + ".sha256"
            print registry_mysql_sha256_url
            download_by_url(registry_mysql_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(registry_mysql_url, registry_mysql_md5_url)

            whois_filename_base = "whois" if version == 'v1' else "whois2"

            csv_name = whois_filename_base + "_mssql.sql.gz"
            whois_mssql_url = url_tld + "/" + csv_name
            print whois_mssql_url
            download_by_url(whois_mssql_url, login, password, final_output_dir)
            whois_mssql_md5_url = whois_mssql_url + ".md5"
            print whois_mssql_md5_url
            download_by_url(whois_mssql_md5_url, login, password, final_output_dir)
            whois_mssql_sha256_url = whois_mssql_url + ".sha256"
            print whois_mssql_sha256_url
            download_by_url(whois_mssql_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(whois_mssql_url, whois_mssql_md5_url)

            csv_name = whois_filename_base + ".sql.gz"
            whois_sql_url = url_tld + "/" + csv_name
            print whois_sql_url
            download_by_url(whois_sql_url, login, password, final_output_dir)
            whois_sql_md5_url = whois_sql_url + ".md5"
            print whois_sql_md5_url
            download_by_url(whois_sql_md5_url, login, password, final_output_dir)
            whois_sql_sha256_url = whois_sql_url + ".sha256"
            print whois_sql_sha256_url
            download_by_url(whois_sql_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(whois_sql_url, whois_sql_md5_url)
            
            csv_name = whois_filename_base + "_record_mysql.sql.gz"
            whois_record_url = url_tld + "/" + csv_name
            print whois_record_url
            download_by_url(whois_record_url, login, password, final_output_dir)
            whois_record_md5_url = whois_record_url + ".md5"
            print whois_record_md5_url
            download_by_url(whois_record_md5_url, login, password, final_output_dir)
            whois_record_sha256_url = whois_record_url + ".sha256"
            print whois_record_sha256_url
            download_by_url(whois_record_sha256_url, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(whois_record_url, whois_record_md5_url)

            # Check file integrity
            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_tld, login, password, interactive, check_sum_dict )

        else:
            for tld in tld_list:
                check_sum_dict = dict()
                final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "mysqldump", tld) )
                table_final_output_dir = os.path.abspath( os.path.join(output_dir, "whois_database", version, "mysqldump", tld, "tables") )
                url_base = url + "/%s/database_dump/mysqldump/%s" % (version, tld)

                correct_tld_format = tld.replace(".", "_")
                csv_name = 'whoiscrawler_%s_%s_mysql.sql.gz' % (version, tld)
                url_tld = url_base + '/' + csv_name
                print final_output_dir 
                print url_tld
                download_by_url(url_tld, login, password, final_output_dir)
                url_tld_md5 = url_tld + ".md5"
                print url_tld_md5
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_tld + ".sha256"
                print url_tld_sha256
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_tld_md5)

                csv_name = 'whoiscrawler_%s_%s_mysql_schema.sql.gz' % (version, tld)
                url_tld = url_base + '/' + csv_name
                print final_output_dir 
                print url_tld
                download_by_url(url_tld, login, password, final_output_dir)
                url_tld_md5 = url_tld + ".md5"
                print url_tld_md5
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_tld + ".sha256"
                print url_tld_sha256
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_tld_md5)

                check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, check_sum_dict )

                # Download Tables 
                url_table_base = url_base + "/tables"

                csv_name = "whoiscrawler_%s_%s_contact_mysql.sql.gz" % (version, correct_tld_format) 
                url_file = url_table_base + "/" + csv_name
                print url_file
                download_by_url(url_file, login, password, table_final_output_dir)
                url_tld_md5 = url_file + ".md5"
                print url_tld_md5
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_file + ".sha256"
                print url_tld_sha256
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_file, url_tld_md5)

                csv_name = "whoiscrawler_%s_%s_domain_names_whoisdatacollector_mysql.sql.gz" % (version, correct_tld_format) 
                url_file = url_table_base + "/" + csv_name
                print url_file
                download_by_url(url_file, login, password, table_final_output_dir)
                url_tld_md5 = url_file + ".md5"
                print url_tld_md5
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_file + ".sha256"
                print url_tld_sha256
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_file, url_tld_md5)

                csv_name = "whoiscrawler_%s_%s_registry_data_mysql.sql.gz" % (version, correct_tld_format) 
                url_file = url_table_base + "/" + csv_name
                print url_file
                download_by_url(url_file, login, password, table_final_output_dir)
                url_tld_md5 = url_file + ".md5"
                print url_tld_md5
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_file + ".sha256"
                print url_tld_sha256
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_file, url_tld_md5)

                csv_name = "whoiscrawler_%s_%s_whois_record_mysql.sql.gz" % (version, correct_tld_format) 
                url_file = url_table_base + "/" + csv_name
                print url_file
                download_by_url(url_file, login, password, table_final_output_dir)
                url_tld_md5 = url_file + ".md5"
                print url_tld_md5
                download_by_url(url_tld_md5, login, password, final_output_dir)
                url_tld_sha256 = url_file + ".sha256"
                print url_tld_sha256
                download_by_url(url_tld_sha256, login, password, final_output_dir)
                check_sum_dict[csv_name] = ChecksumURLs(url_file, url_tld_md5)

                # Check each tld
                check_redownload_if_bad_checksums( dfeed, table_final_output_dir, url_table_base, login, password, interactive, check_sum_dict )

        return 1

    return 0

def download_domain_list_quarterly(url, login, password, file_format, version, interactive,
                                    tld_list=TLD_list,  output_dir = os.path.join(workdir, "data" ) ):
    url_tld = ''
    dfeed = 'domain_list_quarterly'
    #['regular_csv', 'full_csv', 'mysqldump']

    #domain_list_quarterly/v3/csv/tlds/simple/csvs.jp.simple.tar.gz
    print
    if file_format == 'docs':
	url_base = url + "/%s/docs" % (version)
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "docs") )
	# Download .tlds
	url_tlds = url_base + "/%s.tlds" % (version)
	print url_tlds
	download_by_url(url_tlds, login, password, final_output_dir)

	# Download Scripts	
        download_script_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "docs", "download_scripts") )
        url_download_scripts_base = url_base + "/download_scripts"

        url_bash_base = url_download_scripts_base + "/bash"
        final_output_dir = os.path.abspath( os.path.join(download_script_dir, "bash") )
        url_bash_make = url_bash_base + "/Makefile"
        print url_bash_make
	download_by_url(url_bash_make, login, password, final_output_dir)

        url_bash_readme = url_bash_base + "/README"
        print url_bash_readme
	download_by_url(url_bash_readme, login, password, final_output_dir)

        url_bash_ft = url_bash_base + "/ft_whoisdownload"
        print url_bash_ft
	download_by_url(url_bash_ft, login, password, final_output_dir)

        url_bash_sup_gtlds = url_bash_base + "/supported_gtlds"
        print url_bash_sup_gtlds
	download_by_url(url_bash_sup_gtlds, login, password, final_output_dir)

        url_bash_sup_ngtlds = url_bash_base + "/supported_ngtlds"
        print url_bash_sup_ngtlds
	download_by_url(url_bash_sup_ngtlds, login, password, final_output_dir)

        url_bash_tlds = url_bash_base + "/tlds-01.text"
        print url_bash_tlds
	download_by_url(url_bash_tlds, login, password, final_output_dir)

        url_bash_ut_whois_download = url_bash_base + "/ut_whoisdownload"
        print url_bash_ut_whois_download
	download_by_url(url_bash_ut_whois_download, login, password, final_output_dir)

        url_bash_whois_download = url_bash_base + "/whoisdownload.sh"
        print url_bash_whois_download
	download_by_url(url_bash_whois_download, login, password, final_output_dir)

        url_python_base = url_download_scripts_base + "/python"
        final_output_dir = os.path.abspath( os.path.join(download_script_dir, "python") )
        url_python_readme = url_python_base + "/README"
        print url_python_readme
	download_by_url(url_python_readme, login, password, final_output_dir)

        url_python_config = url_python_base + "/config.ini"
        print url_python_config
	download_by_url(url_python_config, login, password, final_output_dir)

        url_python_downloader = url_python_base + "/get_whois_info.py"
        print url_python_downloader
	download_by_url(url_python_downloader, login, password, final_output_dir)

        url_python_sup_gtlds = url_python_base + "/supported_gtlds"
        print url_python_sup_gtlds
	download_by_url(url_python_sup_gtlds, login, password, final_output_dir)

        url_python_sup_ngtlds = url_python_base + "/supported_ngtlds"
        print url_python_sup_ngtlds
	download_by_url(url_python_sup_ngtlds, login, password, final_output_dir)

        return 1

    if file_format == 'readme':
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version) )
	url_readme = url + "/%s/README.txt" % (version)
	print url_readme
	download_by_url(url_readme, login, password, final_output_dir)

        return 1

    if file_format in ['simple_csv', 'regular_csv', 'full_csv']:
        correct_file_name = file_format.split("_")[0]
        final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, correct_file_name) )
        url_base = url + "/%s/csv/tlds/%s" % (version, correct_file_name)

        downloaded_file_names = dict()
        for tld in tld_list:
            filename = "csvs.%s.%s.tar.gz" % (tld, correct_file_name)
            url_tld = url_base + "/" + filename
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)

            url_tld_md5 = url_tld + ".md5"
            print url_tld_md5
            download_by_url(url_tld_md5, login, password, final_output_dir)

            url_tld_sha256 = url_tld + ".sha256"
            print url_tld_sha256
            download_by_url(url_tld_sha256, login, password, final_output_dir)

            # Add file to dict
            downloaded_file_names[filename] = ChecksumURLs(url_tld, url_tld_md5)


        check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, downloaded_file_names )
        return 1

    if file_format == 'mysqldump':
        for tld in tld_list:
            check_sum_dict = dict()
            final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "mysqldump", tld) )
            table_final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "mysqldump", tld, "tables") )
            url_base = url + "/%s/database_dump/mysqldump/%s" % (version, tld)

            correct_tld_format = tld.replace(".", "_")

            csv_name = 'domains_whoiscrawler_%s_%s_mysql.sql.gz' % (version, correct_tld_format)
            url_tld = url_base + '/' + csv_name
            print url_tld
            #final_output_dir = os.path.abspath( os.path.join(output_dir, "domain_list_quarterly", version, "mysqldump") )
            download_by_url(url_tld, login, password, final_output_dir)
            url_tld_md5 = url_tld + ".md5"
            print url_tld_md5
            download_by_url(url_tld_md5, login, password, final_output_dir)
            url_tld_sha256 = url_tld + ".sha256"
            print url_tld_sha256
            download_by_url(url_tld_sha256, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_tld_md5)

            csv_name = 'domains_whoiscrawler_%s_%s_mysql_schema.sql.gz' % (version, correct_tld_format)
            url_tld = url_base + '/' + csv_name
            print url_tld
            download_by_url(url_tld, login, password, final_output_dir)
            url_tld_md5 = url_tld + ".md5"
            print url_tld_md5
            download_by_url(url_tld_md5, login, password, final_output_dir)
            url_tld_sha256 = url_tld + ".sha256"
            print url_tld_sha256
            download_by_url(url_tld_sha256, login, password, final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_tld, url_tld_md5)
            check_redownload_if_bad_checksums( dfeed, final_output_dir, url_base, login, password, interactive, check_sum_dict )

            # Download Tables 
            url_table_base = url_base + "/tables"
            csv_name = "domains_whoiscrawler_%s_%s_contact_mysql.sql.gz" % (version, correct_tld_format)
            url_file = url_table_base + "/" + csv_name
            print url_file
            download_by_url(url_file, login, password, table_final_output_dir)
            url_file_md5 = url_file + ".md5"
            print url_file_md5
            download_by_url(url_file_md5, login, password, table_final_output_dir)
            url_file_sha256 = url_file + ".sha256"
            print url_file_sha256
            download_by_url(url_file_sha256, login, password, table_final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_file, url_file_md5)


            csv_name = "domains_whoiscrawler_%s_%s_domain_names_whoisdatacollector_mysql.sql.gz" % (version, correct_tld_format)
            url_file = url_table_base + "/" + csv_name
            print url_file
            download_by_url(url_file, login, password, table_final_output_dir)
            url_file_md5 = url_file + ".md5"
            print url_file_md5
            download_by_url(url_file_md5, login, password, table_final_output_dir)
            url_file_sha256 = url_file + ".sha256"
            print url_file_sha256
            download_by_url(url_file_sha256, login, password, table_final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_file, url_file_md5)

            csv_name = "domains_whoiscrawler_%s_%s_registry_data_mysql.sql.gz" % (version, correct_tld_format)
            url_file = url_table_base + "/" + csv_name
            print url_file
            download_by_url(url_file, login, password, table_final_output_dir)
            url_file_md5 = url_file + ".md5"
            print url_file_md5
            download_by_url(url_file_md5, login, password, table_final_output_dir)
            url_file_sha256 = url_file + ".sha256"
            print url_file_sha256
            download_by_url(url_file_sha256, login, password, table_final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_file, url_file_md5)

            csv_name = "domains_whoiscrawler_%s_%s_whois_record_mysql.sql.gz" % (version, correct_tld_format)
            url_file = url_table_base + "/" + csv_name
            print url_file
            download_by_url(url_file, login, password, table_final_output_dir)
            url_file_md5 = url_file + ".md5"
            print url_file_md5
            download_by_url(url_file_md5, login, password, table_final_output_dir)
            url_file_sha256 = url_file + ".sha256"
            print url_file_sha256
            download_by_url(url_file_sha256, login, password, table_final_output_dir)
            check_sum_dict[csv_name] = ChecksumURLs(url_file, url_file_md5)

            # Check each tld
            check_redownload_if_bad_checksums( dfeed, table_final_output_dir, url_table_base, login, password, interactive, check_sum_dict )
            
        return 1

    return 0



def dlProgress(count, blockSize, totalSize):
    percent = int(count * blockSize * 100 / totalSize)
    sys.stdout.write("\r" + rem_file + "...%d%%" % percent)
    sys.stdout.flush()

def check_each_combined_tld_part( tld_dir, interactive = True ):
    """
    For loop through all tld_combined parts. If checksums do not match redownload

    Parameters:
        tld_dir: String. Path to combined tld parts.
        interactive: Boolean. Determines if we want the users response before redownload

    Return:
        List. List is of bad filenames to redownload.
    """
    bad_files = list()
    tld_dir = os.path.expanduser(tld_dir)
    tld_dir = os.path.abspath(tld_dir)

    compiled_pattern = re.compile('.*\.[0-9]*$')
    for root, subdir, filelist in os.walk(tld_dir):
        for fn in filelist:
            if( compiled_pattern.match(fn) ):
                file_path = os.path.abspath(os.path.join(root,fn))

                if( not md5_check(file_path, file_path + ".md5") ):
                    bad_files.append(os.path.basename(file_path))

    if( len(bad_files) > 0 ):
        print bad_files
        if( interactive ):
            user_answer = raw_input("Would you like to redownload all these corrupt files [Y/N]: ")
            while( user_answer.upper() not in ["Y", "N", "YES", "NO"] ):
                print "Bad input '{0}'".format( user_answer )
                user_answer = raw_input("Would you like to redownload all these corrupt files [Y/N]: ")
                print

            if( user_answer.upper() in ["Y", "YES"] ):
                print "Redownloading Bad Files"
                print
                return bad_files
            else:
                print "Not redownloading"
                print
                return []
        else:
            print "Redownloading Bad Files"
            print
            return bad_files
        
    return []

def check_redownload_if_bad_checksums( dfeed, dir_files, base_file_url_dir, login, password,interactive = True, files_to_check = dict() ):
    """
    The method will constantly check and redownload bad files until they are 'good'
    
    Parameters
        dfeed: String. Data feed type. Each feeds seems to have own way of handling md5
        dir_files: String. Path to directory of files that we want to check md5 of.
        base_file_url_dir: String. Url to the base directory of files
        login: String. Username to redownload
        password: String. Password to redownload
        interactive: Boolean. Determines if we want to wait for user response for redownload
        files_to_check: Dictionary. If provided use to check those files specifically.
                        Contains file name as key and value of ChecksumURLs

    Return
        Nothing
    """

    # Check if there is a directory first. If not return
    if( not os.path.isdir(dir_files) ):
        return

    print "Checking downloaded files integrity..."

    #Check file integriy
    url_bad_files = check_directories_integrity( dfeed, dir_files, base_file_url_dir,  interactive, files_to_check )
    
    download_bad_files_max_3 = defaultdict(int)
    while( len(url_bad_files) > 0 ):
        for url in url_bad_files:
            download_bad_files_max_3[url] += 1
            print url
            download_by_url(url, login, password, dir_files, False)

        url_bad_files = check_directories_integrity( dfeed, dir_files, base_file_url_dir, interactive, files_to_check )

        # If redownloaded 3 times and fails integrity checker, just stop and log
        for url in list(url_bad_files):
            if(download_bad_files_max_3[url] > 3):
                url_bad_files.remove(url)
                if("md5" not in url):
                    logging.error("{0} has failed md5 check 3 times.".format(url))

    print "File integrity checker complete."

    return

def check_directories_integrity( dfeed, dir_files, base_url_dir, interactive = True, files_to_check = dict() ):
    """
    Searches for all files in a folder 1 levelthat are .tar.gz and compares against the .md5 within that same folder.
    If md5 not found, print error message and store into 'URLS_MISSING_MD5_LIST' but do not redownload.

    Parameters
        dfeed: String. Data feed. Each data feed seems to do things their own ways. We want flexibility
        dir_files: String. Path to directory of files that we want to check md5 of.
        base_url_dir: String. Url to the base directory of files
        interactive: Boolean. Determines if we want to wait for user response for redownload
        files_to_check: Dictionary. Keys = Filename, Value = ChecksumURLs. Allows for easy list of redownload

    Return
        List. Bad file name urls.
    """
    global MISSING_MD5_PATH_LIST
    bad_files = list()
    checksum_urls = list()
    dir_files = os.path.expanduser(dir_files)
    dir_files = os.path.abspath(dir_files)

    # Daily data hash base url is ready when needed. Optimization technique
    if( "ngtld" not in dfeed ):
        hashes_daily_base_url = getDailyGtldUrl(dfeed) + "/hashes"
    else:
        hashes_daily_base_url = getDailyNGtldUrl(dfeed) + "/hashes"

    # Find either files ending in .csv or .gz to check integrity of
    compiled_pattern = re.compile('(.*\.gz$)|(.*\.csv$)')
    for fn in os.listdir(dir_files):
        if( compiled_pattern.match(fn) ):
            file_path = os.path.abspath(os.path.join(dir_files, fn))
            
            # Complex md5 paths
            if( dfeed in ['domain_names_new', 'domain_names_dropped', 'whois_record_delta_domain_names_change'] ):
                tmp, formatted_date = os.path.split(dir_files)
                daily_md5_name = formatted_date + "_" + fn + ".md5"
                md5_path = os.path.abspath(os.path.join(dir_files, daily_md5_name))
            
            # Default paths
            else:
                md5_path = file_path + ".md5"


            if( len(files_to_check) > 0 ): 
                if( fn in files_to_check and not os.path.isfile(md5_path) ):
                     MISSING_MD5_PATH_LIST.add(file_path)
                     continue

                if( fn in files_to_check and not md5_check(file_path, md5_path) ):
                    bad_files.append(files_to_check[fn].file_url)
                    checksum_urls.append(files_to_check[fn].md5_url)
            else:
                if( not os.path.isfile(md5_path) ):
                     MISSING_MD5_PATH_LIST.add(file_path)
                     continue

                # Attempt to redownload based on 'prior knowledge of location' and given base url
                if( not md5_check(file_path, md5_path) ):
                    url_file = base_url_dir + "/" + fn
                    bad_files.append(url_file)

                    if( dfeed in [ 'whois_database', 'domain_list_quarterly' ] ):
                        url_md5 = url_file + ".md5"

                    # YYYY_MM_DD_FILENAME
                    elif( dfeed in [ 'domain_names_new', 'domain_names_dropped', 'whois_record_delta_domain_names_change'] ):
                        formatted_date = base_url_dir.split("/")[-1]
                        url_md5 = hashes_daily_base_url + "/" + formatted_date + "_" + fn + ".md5"

                    else:
                        url_md5 = hashes_daily_base_url + "/" + fn + ".md5"
                        
                    checksum_urls.append(url_md5)


    if( len(bad_files) > 0 ):
        print bad_files
        if( interactive ):
            user_answer = raw_input("Would you like to redownload all these corrupt files [Y/N]: ")
            while( user_answer.upper() not in ["Y", "N", "YES", "NO"] ):
                print "Bad input '{0}'".format( user_answer )
                user_answer = raw_input("Would you like to redownload all these corrupt files [Y/N]: ")
                print

            if( user_answer.upper() in ["Y", "YES"] ):
                print "Redownloading Bad Files"
                print
                print checksum_urls
                bad_files.extend(checksum_urls)
                return bad_files
            else:
                print "Not redownloading"
                print
                return []
        else:
            print "Redownloading Bad Files"
            print
            bad_files.extend(checksum_urls)
            return bad_files
        
    return []

def md5_check( path_filename, md5_file_path ):
    """ Determines if the md5 checksum checks out

    Return:
        Returns a true if the checksum is correct.
    """
    calc_check_sum = calc_md5( path_filename )
    with open( md5_file_path ) as md5_file:
        correct_check_sum = md5_file.readline().split()[0].strip()
        if( calc_check_sum == correct_check_sum ):
            return True
    return False

def calc_md5( path_filename ):
    """ Calculates the md5 of a file
    
    Return:
        Returns the hex digits in string form representing md5 of file
    """
    hash_md5 = hashlib.md5()
    with open( path_filename , "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def getDailyCctldDiscoveredUrl(dfeed_str):
    """
    Constructs base url for daily cctld feed
    """
    return config_downloader.get('cctld', 'daily_discovered_cctld_url') + "/" + dfeed_str

def getDailyCctldRegisteredUrl(dfeed_str):
    """
    Constructs base url for daily cctld feed
    """
    return config_downloader.get('cctld', 'daily_registered_cctld_url') + "/" + dfeed_str

def getDailyGtldUrl( dfeed_str ):
    """Constructs url for daily gtld feed
    
    Parameters:
       dfeed_str: A string representing the feed type

    Return:
        URL representing where a data feed is located
    """
    return config_downloader.get('gtld', 'daily_gtld_url') + "/" + dfeed_str

def getDailyNGtldUrl( dfeed_str ):
    """Constructs url for daily ngtld feed
    
    Parameters:
       dfeed_str: A string representing the feed type

    Return:
        URL representing where a data feed is located
    """
    return config_downloader.get("gtld", "daily_ngtld_url") + "/" + dfeed_str

def getQuarterlyGtldUrl( ):
    """Constructs url for quarterly ngtld feed
    
    Parameters:
       dfeed_str: A string representing the feed type

    Return:
        URL representing where a data feed is located
    """
    return config_downloader.get("gtld", "quarterly_gtld_url")

def getQuarterlyCctldUrl( ):
    """Constructs url for quarterly cctld feed

    Parameters:
        dfeed_str: String representing the data feed type

    Return:
        URL representing where data feed location
    """
    return config_downloader.get("cctld", "quarterly_cctld_url")

def checkSpecifiedTlds( specified_tld, available_tld):
    """
    Checks specified tlds against available. Returns incorrect tlds
    """
def printMissingMD5s():
    """
    Prints out the list of missing md5s if exists
    """
    global MISSING_MD5_PATH_LIST
    if( len(MISSING_MD5_PATH_LIST) > 0 ):
        print
        print "Cannot guarantee the correctness of these files due to missing their md5:"
        for f in sorted(MISSING_MD5_PATH_LIST):
            print f
        print
    
    return

def printIncorrectSpecifiedTlds(correct_tlds, incorrect_specified_tlds):
    """
    Only prints out the correct and incorrect tlds if there are any incorrect specified tlds.
    else Does nothing.
    
    Parameter:
        correct_tlds: list[str]. List of string that represent the correct list of tlds
        incorrect_specified_tlds: list[str]. List of tlds that are were specified by user and incorrect

    Return:
        None
    """
    if( len(incorrect_specified_tlds) > 0 ):
        print
        print "Available tlds:\n{0}".format(correct_tlds)
        print
        print "These specified tlds are not available:\n{0}".format(incorrect_specified_tlds)

dfeed_type = args.dfeed_type
tld = []
output_dir = args.output_dir


# Purpose: Download TLDs list for feed if needed
# Set dfeed_url for daily data. Quarterly release will override this variable.
# Makes it easier to generate daily data-feed urls
if(dfeed_type in ["whois_database", "domain_list_quarterly"]):
    dfeed_url = getQuarterlyGtldUrl() if dfeed_type in ['whois_database'] else getQuarterlyCctldUrl()
elif( dfeed_type in ["ngtld_newly_registered_domains"] ):
    dfeed_url = getDailyNGtldUrl("domain_names_new") 
elif( dfeed_type in ["ngtld_whois_data"] ):
    dfeed_url = getDailyNGtldUrl("domain_names_whois") 
elif( dfeed_type in ["ngtld_recently_dropped_domains"] ):
    dfeed_url = getDailyNGtldUrl("domain_names_dropped") 
elif( dfeed_type in ["ngtld_recently_dropped_whois_domains"] ):
    dfeed_url = getDailyNGtldUrl("domain_names_dropped_whois") 
elif(dfeed_type in ["cctld_discovered_domain_names_whois"]):
    dfeed_url = getDailyCctldDiscoveredUrl("domain_names_whois")
elif(dfeed_type in ["cctld_discovered_domain_names_new"]):
    dfeed_url = getDailyCctldDiscoveredUrl("domain_names_new")
elif(dfeed_type in ["cctld_registered_domain_names_new", "cctld_registered_domain_names_whois", "cctld_registered_domain_names_dropped", "cctld_registered_domain_names_dropped_whois"]):
    dfeed_url = getDailyCctldRegisteredUrl(dfeed_type.replace("cctld_registered_", ""))
else:
    dfeed_url = getDailyGtldUrl(dfeed_type)

TLD_list = get_tlds(dfeed_url, dfeed_type, args.date, args.login, args.password, args.version, args.output_dir)
if args.tld[0] == 'all' and dfeed_type != "whois_database_combined":
    tld = TLD_list
else:
    tld.extend(args.tld)

# Creating subdirectories recursively if they don't exist
mkdir_p(output_dir)


#===========================================
# Quarterly Data Feeds
#===========================================
if dfeed_type == "whois_database_combined":
    dfeed_url = getQuarterlyGtldUrl()

    #http://www.domainwhoisdatabase.com/whois_database/v17/csv/csv_tlds_combined/simple/simple-v15.tar.gz.0000
    if( args.file_format is None ):
        print "Missing file format"
        exit(1)

    if( 'all' in args.file_format ):
        combined_format_list = FORMATS_list
    else:
        combined_format_list = args.file_format

    for f in combined_format_list:
        print "Output dir {0}".format( output_dir )
        print f
        if( f not in ['docs', 'readme'] ):
            download_whois_database_combined( dfeed_url, args.login, args.password, f,
                                    args.version, args.interactive, output_dir )
        else:
            download_whois_database(dfeed_url, args.login, args.password,
                                    f, args.version, args.interactive, tld, output_dir)
    printMissingMD5s()
    sys.exit()

# Here on out, we can specify TLDs
# Check if tld is correct
incorrect_tlds = []
if( 'all' not in args.tld ):
    for t in args.tld:
        if( t not in TLD_list ):
            incorrect_tlds.append(t)
            tld.remove(t)

if dfeed_type == "whois_database":
    dfeed_url = getQuarterlyGtldUrl( )

    if( args.file_format is None ):
        print "Missing file format"
        sys.exit(1)
    elif( args.version == "v1" ):
        if( 'all' in args.file_format ):
            print "Output dir {0}".format(output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'mysqldump', args.version, args.interactive, tld, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'docs', args.version, args.interactive, tld, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'readme', args.version, args.interactive, tld, output_dir)
        elif( 'full_csv' not in args.file_format and 'regular_csv' not in args.file_format \
                and 'simple_csv' not in args.file_format ):
            print "Output dir {0}".format(output_dir)
            for f in args.file_format:
                download_whois_database(dfeed_url, args.login, args.password,
                                    f, args.version, args.interactive, tld, output_dir)

        else:
            print "Database version 1 only contains mysqldump, docs, and readme"
            exit(1)

    elif( args.version == "v2"):
        if( 'all' in args.file_format ):
            print "Output dir {0}".format(output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'simple_csv', args.version, args.interactive, tld, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'mysqldump', args.version, args.interactive, tld, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'docs', args.version, args.interactive, tld, output_dir)
            download_whois_database(dfeed_url, args.login, args.password,
                                    'readme', args.version, args.interactive, tld, output_dir)
        elif( 'full_csv' not in args.file_format and 'regular_csv' not in args.file_format ):
            print "Output dir {0}".format(output_dir)
            for f in args.file_format:
                download_whois_database(dfeed_url, args.login, args.password,
                                    f, args.version, args.interactive, tld, output_dir)
        else:
            print "Database version 2 only contains mysqldump, simple_csv, docs, and readme"
            exit(1)
    else:
        print "Output dir {0}".format(output_dir)
        if( 'all' in args.file_format ):
            for f in FORMATS_list:
                download_whois_database(dfeed_url, args.login, args.password,
                                        f, args.version, args.interactive, tld, output_dir)
        else:
            for f in args.file_format:
                download_whois_database(dfeed_url, args.login, args.password,
                                        f, args.version, args.interactive, tld, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "domain_list_quarterly":
    dfeed_url = getQuarterlyCctldUrl( )


    #http://www.domainwhoisdatabase.com/domain_list_quarterly/v3/database_dump/mysqldump/info/domains_whoiscrawler_v3_info_mysql.sql.gz
    if( args.file_format is None ):
        print "Missing file format"
        sys.exit(1)

    if( 'all' in args.file_format ):
        domain_list_quarterly = FORMATS_list
    else:
        domain_list_quarterly = args.file_format

    for f in domain_list_quarterly:
        print "Output dir {0}".format( output_dir )
        download_domain_list_quarterly(dfeed_url, args.login, args.password,
                                f, args.version, args.interactive, tld, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


#===========================================
# Daily Data Feeds
#===========================================
# After quarterly release, check if date is present.
# Date is needed for daily data
if( args.date is None ):
    print "Date required: Date (format YYYY-MM-DD)"
    sys.exit(1)

if dfeed_type == "domain_names_new":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_new(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_dropped":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_dropped(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_filtered_reg_country":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_filtered_reg_country(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_filtered_reg_country_noproxy":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_filtered_reg_country_noproxy(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "whois_record_delta_domain_names_change":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_whois_record_delta_domain_names_change(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "whois_record_delta_whois":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_whois_record_delta_whois(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_archive":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_archive(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_filtered_reg_country_archive":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_filtered_reg_country_archive(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_whois_filtered_reg_country_noproxy_archive":
    dfeed_url = getDailyGtldUrl( dfeed_type )
    download_domain_names_whois_filtered_reg_country_noproxy_archive(dfeed_url, args.date, args.login, 
                                                        args.password, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "ngtld_newly_registered_domains":
    dfeed_url = getDailyNGtldUrl( "domain_names_new" )
    download_domain_names_new(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_recently_dropped_domains":
    dfeed_url = getDailyNGtldUrl( "domain_names_dropped" )
    download_domain_names_dropped(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "cctld_discovered_domain_names_new":
    dfeed_url = getDailyCctldDiscoveredUrl("domain_names_new")
    download_domain_names_new(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "cctld_registered_domain_names_new":
    dfeed_url = getDailyCctldRegisteredUrl("domain_names_new")
    download_domain_names_new(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "cctld_registered_domain_names_dropped":
    dfeed_url = getDailyCctldRegisteredUrl("domain_names_dropped")
    download_domain_names_dropped(dfeed_url, args.date, args.login, args.password,
                              tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

# Check file format
file_format = args.file_format
domain_names_file_format = ["regular_csv", "full_csv", "mysqldump"]
valid_user_file_formats = domain_names_file_format + ["all"]
if( args.file_format is None ):
    print "Missing file format"
    print "Valid formats: {0}".format(domain_names_file_format)
    sys.exit(1)

for ff in file_format:
    if ff not in valid_user_file_formats:
        print "You have to specify --file-format properly (%s) for this type of data_feed (%s)" % (
            valid_user_file_formats, dfeed_type)
        printMissingMD5s()
        printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
        sys.exit()

if dfeed_type == "domain_names_whois":
    dfeed_url = getDailyGtldUrl( dfeed_type )

    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, 
                    ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, 
                    ff, tld, args.end_date, args.interactive, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_whois_data":
    dfeed_url = getDailyNGtldUrl( "domain_names_whois" )
    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "cctld_discovered_domain_names_whois":
    dfeed_url = getDailyCctldDiscoveredUrl("domain_names_whois")

    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, ff, tld, args.end_date, args.interactive, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "cctld_registered_domain_names_whois":
    dfeed_url = getDailyCctldRegisteredUrl("domain_names_whois")

    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_whois(dfeed_url, args.date, args.login, args.password, ff, tld, args.end_date, args.interactive, output_dir)

    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "domain_names_dropped_whois":
    dfeed_url = getDailyGtldUrl( "domain_names_dropped_whois" )
    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

if dfeed_type == "ngtld_recently_dropped_whois_domains":
    dfeed_url = getDailyNGtldUrl( "domain_names_dropped_whois" )
    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()


if dfeed_type == "cctld_registered_domain_names_dropped_whois":
    dfeed_url = getDailyCctldRegisteredUrl("domain_names_dropped_whois")
    if("all" in file_format):
        for ff in domain_names_file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    else:
        for ff in file_format:
            download_domain_names_dropped_whois(dfeed_url, args.date, args.login, args.password,
                                  ff, tld, args.end_date, args.interactive, output_dir)
    printMissingMD5s()
    printIncorrectSpecifiedTlds(TLD_list, incorrect_tlds)
    sys.exit()

